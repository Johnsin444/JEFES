package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class ReyHongoModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "rey_hongo"), "main");

    private final ModelPart armL;
    private final ModelPart armR;
    private final ModelPart cap;

    public ReyHongoModel(ModelPart root) {
        super(root);
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.cap = root.getChild("cap");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("roots",
                CubeListBuilder.create()
                        .texOffs(0, 87).addBox(-12f, -5f, -12f, 24f, 5f, 24f)
                        .texOffs(0, 133).addBox(-26f, -3f, -3f, 14f, 3f, 6f)
                        .texOffs(40, 133).addBox(12f, -3f, -3f, 14f, 3f, 6f)
                        .texOffs(208, 87).addBox(-3f, -3f, -26f, 6f, 3f, 14f)
                        .texOffs(0, 116).addBox(-3f, -3f, 12f, 6f, 3f, 14f)
                        .texOffs(104, 133).addBox(-20f, -2f, -17f, 10f, 2f, 5f)
                        .texOffs(134, 133).addBox(10f, -2f, 12f, 10f, 2f, 5f)
                        .texOffs(164, 133).addBox(10f, -2f, -17f, 10f, 2f, 5f)
                        .texOffs(194, 133).addBox(-20f, -2f, 12f, 10f, 2f, 5f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("trunk",
                CubeListBuilder.create()
                        .texOffs(176, 0).addBox(-10f, -28f, -10f, 20f, 23f, 20f)
                        .texOffs(0, 51).addBox(-8f, -48f, -8f, 16f, 20f, 16f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("shelf",
                CubeListBuilder.create()
                        .texOffs(152, 116).addBox(10f, -20f, -4f, 8f, 2f, 8f)
                        .texOffs(184, 116).addBox(-18f, -32f, -4f, 8f, 2f, 8f)
                        .texOffs(80, 133).addBox(8f, -40f, -3f, 6f, 2f, 6f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("cap",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-22f, -56f, -22f, 44f, 7f, 44f)
                        .texOffs(64, 51).addBox(-15f, -62f, -15f, 30f, 6f, 30f)
                        .texOffs(96, 87).addBox(-9f, -66f, -9f, 18f, 4f, 18f)
                        .texOffs(40, 116).addBox(-7f, -69f, -7f, 14f, 3f, 14f)
                        .texOffs(224, 133).addBox(-7f, -73f, -7f, 3f, 4f, 3f)
                        .texOffs(236, 133).addBox(4f, -73f, -7f, 3f, 4f, 3f)
                        .texOffs(0, 142).addBox(-7f, -73f, 4f, 3f, 4f, 3f)
                        .texOffs(12, 142).addBox(4f, -73f, 4f, 3f, 4f, 3f)
                        .texOffs(216, 116).addBox(-1f, -76f, -1f, 3f, 7f, 3f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("arm_l",
                CubeListBuilder.create()
                        .texOffs(168, 87).addBox(-2f, 0f, -2f, 5f, 14f, 5f)
                        .texOffs(96, 116).addBox(-3f, 14f, -3f, 7f, 7f, 7f),
                PartPose.offset(11f, -12f, 0f));
        root.addOrReplaceChild("arm_r",
                CubeListBuilder.create()
                        .texOffs(188, 87).addBox(-3f, 0f, -2f, 5f, 14f, 5f)
                        .texOffs(124, 116).addBox(-4f, 14f, -3f, 7f, 7f, 7f),
                PartPose.offset(-11f, -12f, 0f));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float t = state.ageInTicks;
        armL.xRot = Mth.sin(t * 0.05f) * 0.12f;
        armR.xRot = -Mth.sin(t * 0.05f) * 0.12f;
        armL.zRot = -(0.25f + Mth.sin(t * 0.07f) * 0.08f);
        armR.zRot = 0.25f + Mth.sin(t * 0.07f + 1.0f) * 0.08f;
        cap.zRot = Mth.sin(t * 0.03f) * 0.02f;
    }
}
