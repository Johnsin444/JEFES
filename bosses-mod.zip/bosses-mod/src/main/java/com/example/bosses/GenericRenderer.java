package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

public class GenericRenderer<T extends Mob> extends MobRenderer<T, HongoRenderState, EntityModel<HongoRenderState>> {
    private final Identifier texture;

    public GenericRenderer(EntityRendererProvider.Context context, EntityModel<HongoRenderState> model,
                           Identifier texture, float shadow) {
        super(context, model, shadow);
        this.texture = texture;
    }

    @Override
    public HongoRenderState createRenderState() {
        return new HongoRenderState();
    }

    @Override
    public Identifier getTextureLocation(HongoRenderState state) {
        return texture;
    }
}
