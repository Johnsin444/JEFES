package com.example.bosses;

import net.minecraft.util.Mth;

/** Utilidades de animacion procedural compartidas por todos los modelos. */
public final class Anim {
    private Anim() {}

    /** 0 -> 1 -> 0 durante el golpe (attackTime va de 0 a 1). */
    public static float swing(HongoRenderState s) {
        return Mth.sin(s.attackTime * (float) Math.PI);
    }

    /** Golpe con anticipacion: primero se echa atras (negativo) y luego pega fuerte (positivo). */
    public static float strike(HongoRenderState s) {
        float a = s.attackTime;
        if (a <= 0.0f) return 0.0f;
        if (a < 0.3f) return -Mth.sin(a / 0.3f * (float) Math.PI) * 0.4f;
        return Mth.sin((a - 0.3f) / 0.7f * (float) Math.PI);
    }

    /** Intensidad de movimiento 0..1. */
    public static float walk(HongoRenderState s) {
        return Math.min(1.0f, s.walkAnimationSpeed * 2.0f);
    }

    /** Giro de cabeza hacia donde mira la entidad (radianes). */
    public static float lookY(HongoRenderState s) {
        return (float) Math.toRadians(Mth.clamp(s.yRot, -45.0f, 45.0f));
    }

    public static float lookX(HongoRenderState s) {
        return (float) Math.toRadians(Mth.clamp(s.xRot, -30.0f, 30.0f));
    }

    /** Rebote al caminar (siempre >= 0). */
    public static float hop(HongoRenderState s, float speed) {
        return Math.abs(Mth.sin(s.walkAnimationPos * speed)) * walk(s);
    }
}
