package com.example.bosses;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class HongoRenderer extends MobRenderer<ReyHongo, HongoRenderState, HongoModel> {
    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "textures/entity/rey_hongo.png");

    public HongoRenderer(EntityRendererProvider.Context context) {
        super(context, new HongoModel(context.bakeLayer(HongoModel.LAYER)), 0.9f);
    }

    @Override
    public HongoRenderState createRenderState() {
        return new HongoRenderState();
    }

    @Override
    public Identifier getTextureLocation(HongoRenderState state) {
        return TEXTURE;
    }
}
