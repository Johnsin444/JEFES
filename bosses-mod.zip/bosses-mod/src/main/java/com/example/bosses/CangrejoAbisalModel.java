package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class CangrejoAbisalModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "cangrejo_abisal"), "main");

    private final ModelPart eyeL;
    private final ModelPart eyeR;
    private final ModelPart clawL;
    private final ModelPart clawR;
    private final ModelPart legL0;
    private final ModelPart legL1;
    private final ModelPart legR0;
    private final ModelPart legR1;

    public CangrejoAbisalModel(ModelPart root) {
        super(root);
        this.eyeL = root.getChild("eye_l");
        this.eyeR = root.getChild("eye_r");
        this.clawL = root.getChild("claw_l");
        this.clawR = root.getChild("claw_r");
        this.legL0 = root.getChild("leg_l0");
        this.legL1 = root.getChild("leg_l1");
        this.legR0 = root.getChild("leg_r0");
        this.legR1 = root.getChild("leg_r1");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(8, 0).addBox(-9f, -12f, -7f, 18f, 8f, 14f)
                        .texOffs(0, 40).addBox(-7f, -14f, -5f, 14f, 2f, 10f)
                        .texOffs(8, 64).addBox(-6f, -17f, -3f, 2f, 3f, 2f)
                        .texOffs(112, 52).addBox(-1f, -18f, -3f, 2f, 4f, 2f)
                        .texOffs(16, 64).addBox(4f, -17f, -3f, 2f, 3f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("eye_l",
                CubeListBuilder.create()
                        .texOffs(120, 52).addBox(-1f, -4f, -1f, 2f, 4f, 2f)
                        .texOffs(80, 52).addBox(-2f, -7f, -2f, 4f, 3f, 4f),
                PartPose.offset(3f, 12f, -6f));
        root.addOrReplaceChild("claw_l",
                CubeListBuilder.create()
                        .texOffs(48, 40).addBox(-2f, -2f, -8f, 4f, 4f, 8f)
                        .texOffs(72, 40).addBox(-3f, -3f, -14f, 6f, 6f, 6f),
                PartPose.offset(10f, 16f, -5f));
        root.addOrReplaceChild("leg_l0",
                CubeListBuilder.create()
                        .texOffs(24, 64).addBox(0f, -1f, -1f, 8f, 2f, 2f)
                        .texOffs(32, 52).addBox(7f, -1f, -1f, 2f, 6f, 2f),
                PartPose.offset(8f, 18f, -3f));
        root.addOrReplaceChild("leg_l1",
                CubeListBuilder.create()
                        .texOffs(24, 64).addBox(0f, -1f, -1f, 8f, 2f, 2f)
                        .texOffs(32, 52).addBox(7f, -1f, -1f, 2f, 6f, 2f),
                PartPose.offset(8f, 18f, 3f));
        root.addOrReplaceChild("eye_r",
                CubeListBuilder.create()
                        .texOffs(120, 52).addBox(-1f, -4f, -1f, 2f, 4f, 2f)
                        .texOffs(80, 52).addBox(-2f, -7f, -2f, 4f, 3f, 4f),
                PartPose.offset(-3f, 12f, -6f));
        root.addOrReplaceChild("claw_r",
                CubeListBuilder.create()
                        .texOffs(48, 40).addBox(-2f, -2f, -8f, 4f, 4f, 8f)
                        .texOffs(72, 40).addBox(-3f, -3f, -14f, 6f, 6f, 6f),
                PartPose.offset(-10f, 16f, -5f));
        root.addOrReplaceChild("leg_r0",
                CubeListBuilder.create()
                        .texOffs(64, 64).addBox(-8f, -1f, -1f, 8f, 2f, 2f)
                        .texOffs(48, 52).addBox(-9f, -1f, -1f, 2f, 6f, 2f),
                PartPose.offset(-8f, 18f, -3f));
        root.addOrReplaceChild("leg_r1",
                CubeListBuilder.create()
                        .texOffs(64, 64).addBox(-8f, -1f, -1f, 8f, 2f, 2f)
                        .texOffs(48, 52).addBox(-9f, -1f, -1f, 2f, 6f, 2f),
                PartPose.offset(-8f, 18f, 3f));
        root.addOrReplaceChild("trident",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1f, -30f, -1f, 2f, 38f, 2f)
                        .texOffs(64, 52).addBox(-4f, -34f, -1f, 2f, 6f, 2f)
                        .texOffs(24, 52).addBox(-1f, -36f, -1f, 2f, 7f, 2f)
                        .texOffs(72, 52).addBox(2f, -34f, -1f, 2f, 6f, 2f)
                        .texOffs(104, 64).addBox(-4f, -30f, -1f, 8f, 2f, 2f),
                PartPose.offset(-14f, 12f, -16f));
        root.addOrReplaceChild("shield",
                CubeListBuilder.create()
                        .texOffs(72, 0).addBox(-7f, -8f, -1f, 14f, 16f, 2f),
                PartPose.offset(15f, 10f, -10f));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        clawL.xRot = Mth.sin(t * 0.2f) * 0.1f;
        clawR.xRot = -Mth.sin(t * 0.2f) * 0.1f;
        eyeL.yRot = Mth.sin(t * 0.07f) * 0.2f;
        eyeR.yRot = -Mth.sin(t * 0.07f) * 0.2f;
        legL0.zRot = 0.2f + Mth.cos(p * 0.9f) * 0.35f * sp;
        legL1.zRot = 0.2f + Mth.cos(p * 0.9f + 3.14f) * 0.35f * sp;
        legR0.zRot = -(0.2f + Mth.cos(p * 0.9f + 3.14f) * 0.35f * sp);
        legR1.zRot = -(0.2f + Mth.cos(p * 0.9f) * 0.35f * sp);
    }
}
