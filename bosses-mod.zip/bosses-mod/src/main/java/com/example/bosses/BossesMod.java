package com.example.bosses;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class BossesMod implements ModInitializer {
    public static final String MOD_ID = "bosses";

    public static final ResourceKey<EntityType<?>> REY_HONGO_KEY = ResourceKey.create(
            Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, "rey_hongo"));

    public static final EntityType<ReyHongo> REY_HONGO = Registry.register(
            BuiltInRegistries.ENTITY_TYPE, REY_HONGO_KEY,
            EntityType.Builder.of(ReyHongo::new, MobCategory.MONSTER)
                    .sized(1.9f, 2.7f)
                    .clientTrackingRange(10)
                    .build(REY_HONGO_KEY));

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(REY_HONGO, ReyHongo.createAttributes());

        ResourceKey<Item> crownKey = ResourceKey.create(Registries.ITEM,
                Identifier.fromNamespaceAndPath(MOD_ID, "spore_crown"));
        Item crown = new Item(new Item.Properties().stacksTo(1).setId(crownKey));
        Registry.register(BuiltInRegistries.ITEM, crownKey, crown);
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS)
                .register(output -> output.accept(crown));
    }
}
