package com.example.bosses;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class BossesMod implements ModInitializer {
    public static final String MOD_ID = "bosses";

    private static <T extends Entity> EntityType<T> reg(String id, EntityType.EntityFactory<T> factory,
                                                         float w, float h, int tracking) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(
                Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, id));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key,
                EntityType.Builder.of(factory, MobCategory.MONSTER)
                        .sized(w, h).clientTrackingRange(tracking).build(key));
    }

    public static final EntityType<ReyHongo> REY_HONGO = reg("rey_hongo", ReyHongo::new, 2.6f, 4.6f, 10);
    public static final EntityType<HongoMini> HONGO_MINI = reg("hongo_mini", HongoMini::new, 0.7f, 1.1f, 8);

    public static final EntityType<CangrejoColoso> CANGREJO_COLOSO =
            reg("cangrejo_coloso", CangrejoColoso::new, 3.0f, 2.5f, 10);
    public static final EntityType<EspectroFaro> ESPECTRO_FARO =
            reg("espectro_faro", EspectroFaro::new, 1.4f, 3.0f, 10);
    public static final EntityType<BuhoEclipse> BUHO_ECLIPSE =
            reg("buho_eclipse", BuhoEclipse::new, 1.8f, 3.0f, 10);

    public static final EntityType<SimpleMini> CANGREJITO = reg("cangrejito", SimpleMini::new, 0.9f, 0.9f, 8);
    public static final EntityType<SimpleMini> FANTASMITA = reg("fantasmita", SimpleMini::new, 0.6f, 1.0f, 8);
    public static final EntityType<SimpleMini> POLLUELO = reg("polluelo", SimpleMini::new, 0.6f, 0.9f, 8);

    private static Item item(String id) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, id));
        Item item = new Item(new Item.Properties().stacksTo(1).setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS)
                .register(output -> output.accept(item));
        return item;
    }

    @Override
    public void onInitialize() {
        ModSounds.init();
        ModItems.init();
        FabricDefaultAttributeRegistry.register(REY_HONGO, ReyHongo.createAttributes());
        FabricDefaultAttributeRegistry.register(HONGO_MINI, HongoMini.createAttributes());
        FabricDefaultAttributeRegistry.register(CANGREJO_COLOSO, CangrejoColoso.createAttributes());
        FabricDefaultAttributeRegistry.register(ESPECTRO_FARO, EspectroFaro.createAttributes());
        FabricDefaultAttributeRegistry.register(BUHO_ECLIPSE, BuhoEclipse.createAttributes());
        FabricDefaultAttributeRegistry.register(CANGREJITO, SimpleMini.createAttributes(20.0, 5.0, 0.3));
        FabricDefaultAttributeRegistry.register(FANTASMITA, SimpleMini.createAttributes(18.0, 4.0, 0.28));
        FabricDefaultAttributeRegistry.register(POLLUELO, SimpleMini.createAttributes(16.0, 4.0, 0.32));

        item("spore_crown");
        item("coral_claw");
        item("eternal_lantern");
        item("moon_feather");
    }
}
