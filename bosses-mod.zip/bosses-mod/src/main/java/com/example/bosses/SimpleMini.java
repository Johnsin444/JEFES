package com.example.bosses;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Mini enemigo generico: se registra varias veces con distinto modelo. */
public class SimpleMini extends Monster {
    public SimpleMini(EntityType<? extends SimpleMini> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes(double health, double damage, double speed) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ATTACK_DAMAGE, damage)
                .add(Attributes.FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1, true));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 10.0f));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected SoundEvent getAmbientSound() {
        if (getType() == BossesMod.CANGREJITO) return ModSounds.CANGREJITO_AMBIENT;
        if (getType() == BossesMod.FANTASMITA) return ModSounds.FANTASMITA_AMBIENT;
        return ModSounds.POLLUELO_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        if (getType() == BossesMod.CANGREJITO) return ModSounds.CANGREJITO_HURT;
        if (getType() == BossesMod.FANTASMITA) return ModSounds.FANTASMITA_HURT;
        return ModSounds.POLLUELO_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        if (getType() == BossesMod.CANGREJITO) return ModSounds.CANGREJITO_DEATH;
        if (getType() == BossesMod.FANTASMITA) return ModSounds.FANTASMITA_DEATH;
        return ModSounds.POLLUELO_DEATH;
    }
}
