package com.example.bosses;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** GENERADO: bloques tematicos de las 4 dungeons (ladrillos, agrietados, cincelado, pilar, lampara, losa, escaleras, escombros). */
public final class ModBlocks {
    private ModBlocks() {}

    public static final String[] THEMES = {"sporestone", "coralshell", "wraithstone", "moonslate"};
    public static final Map<String, Block> ALL = new LinkedHashMap<>();

    private static Block reg(String id, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, id));
        Block block = Registry.register(BuiltInRegistries.BLOCK, key, factory.apply(props.setId(key)));
        ResourceKey<Item> ikey = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, id));
        BlockItem item = Registry.register(BuiltInRegistries.ITEM, ikey,
                new BlockItem(block, new Item.Properties().setId(ikey).useBlockDescriptionPrefix()));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.BUILDING_BLOCKS).register(o -> o.accept(item));
        ALL.put(id, block);
        return block;
    }

    private static BlockBehaviour.Properties stone() {
        return BlockBehaviour.Properties.of().strength(3.0f, 9.0f).requiresCorrectToolForDrops().sound(SoundType.STONE);
    }

    public static Block get(String id) {
        return ALL.get(id);
    }

    public static void init() {
        for (String t : THEMES) {
            Block bricks = reg(t + "_bricks", Block::new, stone());
            reg(t + "_cracked_bricks", Block::new, stone());
            reg(t + "_chiseled", Block::new, stone());
            reg(t + "_pillar", RotatedPillarBlock::new, stone());
            reg(t + "_lamp", Block::new, stone().lightLevel(s -> 14).sound(SoundType.GLASS).strength(1.5f));
            reg(t + "_bricks_slab", SlabBlock::new, stone());
            reg(t + "_bricks_stairs", p -> new StairBlock(bricks.defaultBlockState(), p), stone());
            reg(t + "_rubble", Block::new, BlockBehaviour.Properties.of().strength(1.0f, 2.0f).sound(SoundType.GRAVEL));
        }
    }
}
