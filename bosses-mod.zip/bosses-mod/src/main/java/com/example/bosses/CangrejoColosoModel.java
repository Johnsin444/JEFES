package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class CangrejoColosoModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "cangrejo_coloso"), "main");

    private final ModelPart eyeL;
    private final ModelPart eyeR;
    private final ModelPart fingerUpL;
    private final ModelPart fingerUpR;
    private final ModelPart legL0;
    private final ModelPart legL1;
    private final ModelPart legL2;
    private final ModelPart legL3;
    private final ModelPart legR0;
    private final ModelPart legR1;
    private final ModelPart legR2;
    private final ModelPart legR3;

    public CangrejoColosoModel(ModelPart root) {
        super(root);
        this.eyeL = root.getChild("eye_l");
        this.eyeR = root.getChild("eye_r");
        this.fingerUpL = root.getChild("finger_up_l");
        this.fingerUpR = root.getChild("finger_up_r");
        this.legL0 = root.getChild("leg_l0");
        this.legL1 = root.getChild("leg_l1");
        this.legL2 = root.getChild("leg_l2");
        this.legL3 = root.getChild("leg_l3");
        this.legR0 = root.getChild("leg_r0");
        this.legR1 = root.getChild("leg_r1");
        this.legR2 = root.getChild("leg_r2");
        this.legR3 = root.getChild("leg_r3");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(8, 0).addBox(-13f, -21f, -9f, 26f, 14f, 18f)
                        .texOffs(88, 88).addBox(-9f, -19f, -10f, 18f, 10f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("collar",
                CubeListBuilder.create()
                        .texOffs(0, 48).addBox(-14f, -24f, -10f, 28f, 4f, 20f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("cape",
                CubeListBuilder.create()
                        .texOffs(96, 0).addBox(-12f, -24f, 10f, 24f, 24f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("pauldrons",
                CubeListBuilder.create()
                        .texOffs(96, 48).addBox(-19f, -25f, -6f, 6f, 6f, 12f)
                        .texOffs(132, 48).addBox(13f, -25f, -6f, 6f, 6f, 12f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("crown",
                CubeListBuilder.create()
                        .texOffs(0, 72).addBox(-8f, -28f, -4f, 16f, 4f, 12f)
                        .texOffs(56, 72).addBox(-7f, -34f, -3f, 14f, 6f, 10f)
                        .texOffs(222, 88).addBox(-8f, -38f, -4f, 3f, 4f, 3f)
                        .texOffs(234, 88).addBox(5f, -38f, -4f, 3f, 4f, 3f)
                        .texOffs(0, 104).addBox(-8f, -38f, 5f, 3f, 4f, 3f)
                        .texOffs(12, 104).addBox(5f, -38f, 5f, 3f, 4f, 3f)
                        .texOffs(24, 104).addBox(-1f, -37f, -2f, 3f, 3f, 3f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("scepter",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1f, -46f, -1f, 2f, 46f, 2f)
                        .texOffs(36, 104).addBox(-2f, -30f, -2f, 4f, 2f, 4f)
                        .texOffs(64, 88).addBox(-3f, -52f, -3f, 6f, 6f, 6f)
                        .texOffs(68, 104).addBox(-2f, -47f, -2f, 4f, 1f, 4f),
                PartPose.offset(15f, 24f, -23f));
        root.addOrReplaceChild("shield",
                CubeListBuilder.create()
                        .texOffs(148, 0).addBox(-8f, -22f, -2f, 16f, 22f, 3f),
                PartPose.offset(-15f, 24f, -31f));
        root.addOrReplaceChild("eye_l",
                CubeListBuilder.create()
                        .texOffs(52, 104).addBox(-1f, -27f, -1f, 2f, 4f, 2f)
                        .texOffs(190, 88).addBox(-2f, -31f, -2f, 4f, 4f, 4f),
                PartPose.offset(5f, 24f, -8f));
        root.addOrReplaceChild("arm_l",
                CubeListBuilder.create()
                        .texOffs(104, 72).addBox(-2f, -2f, -12f, 4f, 4f, 12f)
                        .texOffs(168, 48).addBox(-4f, -4f, -22f, 8f, 8f, 10f),
                PartPose.offset(15f, 8f, -6f));
        root.addOrReplaceChild("finger_up_l",
                CubeListBuilder.create()
                        .texOffs(136, 72).addBox(-2f, -4f, -12f, 4f, 4f, 12f),
                PartPose.offset(15f, 8f, -28f));
        root.addOrReplaceChild("finger_low_l",
                CubeListBuilder.create()
                        .texOffs(168, 72).addBox(-2f, 0f, -12f, 4f, 4f, 12f),
                PartPose.offset(15f, 8f, -28f));
        root.addOrReplaceChild("leg_l0",
                CubeListBuilder.create()
                        .texOffs(84, 104).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(126, 88).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(12f, 17f, -6f));
        root.addOrReplaceChild("leg_l1",
                CubeListBuilder.create()
                        .texOffs(84, 104).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(126, 88).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(12f, 17f, -2f));
        root.addOrReplaceChild("leg_l2",
                CubeListBuilder.create()
                        .texOffs(84, 104).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(126, 88).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(12f, 17f, 2f));
        root.addOrReplaceChild("leg_l3",
                CubeListBuilder.create()
                        .texOffs(84, 104).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(126, 88).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(12f, 17f, 6f));
        root.addOrReplaceChild("eye_r",
                CubeListBuilder.create()
                        .texOffs(52, 104).addBox(-1f, -27f, -1f, 2f, 4f, 2f)
                        .texOffs(190, 88).addBox(-2f, -31f, -2f, 4f, 4f, 4f),
                PartPose.offset(-5f, 24f, -8f));
        root.addOrReplaceChild("arm_r",
                CubeListBuilder.create()
                        .texOffs(104, 72).addBox(-2f, -2f, -12f, 4f, 4f, 12f)
                        .texOffs(168, 48).addBox(-4f, -4f, -22f, 8f, 8f, 10f),
                PartPose.offset(-15f, 8f, -6f));
        root.addOrReplaceChild("finger_up_r",
                CubeListBuilder.create()
                        .texOffs(136, 72).addBox(-2f, -4f, -12f, 4f, 4f, 12f),
                PartPose.offset(-15f, 8f, -28f));
        root.addOrReplaceChild("finger_low_r",
                CubeListBuilder.create()
                        .texOffs(168, 72).addBox(-2f, 0f, -12f, 4f, 4f, 12f),
                PartPose.offset(-15f, 8f, -28f));
        root.addOrReplaceChild("leg_r0",
                CubeListBuilder.create()
                        .texOffs(180, 104).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(158, 88).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-12f, 17f, -6f));
        root.addOrReplaceChild("leg_r1",
                CubeListBuilder.create()
                        .texOffs(180, 104).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(158, 88).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-12f, 17f, -2f));
        root.addOrReplaceChild("leg_r2",
                CubeListBuilder.create()
                        .texOffs(180, 104).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(158, 88).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-12f, 17f, 2f));
        root.addOrReplaceChild("leg_r3",
                CubeListBuilder.create()
                        .texOffs(180, 104).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(158, 88).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-12f, 17f, 6f));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        fingerUpL.xRot = -(0.12f + (Mth.sin(t * 0.12f) + 1.0f) * 0.22f);
        fingerUpR.xRot = -(0.12f + (Mth.sin(t * 0.12f + 1.5f) + 1.0f) * 0.22f);
        eyeL.yRot = Mth.sin(t * 0.07f) * 0.25f;
        eyeR.yRot = -Mth.sin(t * 0.07f) * 0.25f;
        ModelPart[] legsL = {legL0, legL1, legL2, legL3};
        ModelPart[] legsR = {legR0, legR1, legR2, legR3};
        for (int i = 0; i < 4; i++) {
            legsL[i].zRot = 0.15f + Mth.cos(p * 0.9f + i * 0.9f) * 0.35f * sp;
            legsR[i].zRot = -(0.15f + Mth.cos(p * 0.9f + i * 0.9f + 3.14f) * 0.35f * sp);
        }
        float sw = Anim.strike(state);
        fingerUpL.xRot += sw * 0.8f;
        fingerUpR.xRot += sw * 0.8f;
        this.root().y = -Anim.hop(state, 0.9f) * 1.2f + Mth.sin(t * 0.07f) * 0.4f;
        this.root().xRot = sw * 0.1f + sp * 0.03f;
        this.root().zRot = Mth.sin(p * 0.9f) * 0.03f * sp;
    }
}
