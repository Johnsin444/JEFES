package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class CangrejoColosoModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "cangrejo_coloso"), "main");

    private final ModelPart eyeL;
    private final ModelPart eyeR;
    private final ModelPart fingerUpL;
    private final ModelPart fingerUpR;
    private final ModelPart legL0;
    private final ModelPart legL1;
    private final ModelPart legL2;
    private final ModelPart legL3;
    private final ModelPart legR0;
    private final ModelPart legR1;
    private final ModelPart legR2;
    private final ModelPart legR3;

    public CangrejoColosoModel(ModelPart root) {
        super(root);
        this.eyeL = root.getChild("eye_l");
        this.eyeR = root.getChild("eye_r");
        this.fingerUpL = root.getChild("finger_up_l");
        this.fingerUpR = root.getChild("finger_up_r");
        this.legL0 = root.getChild("leg_l0");
        this.legL1 = root.getChild("leg_l1");
        this.legL2 = root.getChild("leg_l2");
        this.legL3 = root.getChild("leg_l3");
        this.legR0 = root.getChild("leg_r0");
        this.legR1 = root.getChild("leg_r1");
        this.legR2 = root.getChild("leg_r2");
        this.legR3 = root.getChild("leg_r3");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-12f, -14f, -9f, 24f, 10f, 18f)
                        .texOffs(0, 62).addBox(-9f, -17f, -6f, 18f, 3f, 12f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("eye_l",
                CubeListBuilder.create()
                        .texOffs(32, 77).addBox(-1f, -5f, -1f, 2f, 5f, 2f)
                        .texOffs(0, 77).addBox(-2f, -9f, -2f, 4f, 4f, 4f),
                PartPose.offset(5f, 10f, -8f));
        root.addOrReplaceChild("arm_l",
                CubeListBuilder.create()
                        .texOffs(36, 28).addBox(-2f, -2f, -12f, 4f, 4f, 12f)
                        .texOffs(84, 0).addBox(-4f, -4f, -22f, 8f, 8f, 10f),
                PartPose.offset(13f, 15f, -6f));
        root.addOrReplaceChild("finger_up_l",
                CubeListBuilder.create()
                        .texOffs(68, 28).addBox(-2f, -4f, -12f, 4f, 4f, 12f),
                PartPose.offset(13f, 15f, -28f));
        root.addOrReplaceChild("finger_low_l",
                CubeListBuilder.create()
                        .texOffs(0, 46).addBox(-2f, 0f, -12f, 4f, 4f, 12f),
                PartPose.offset(13f, 15f, -28f));
        root.addOrReplaceChild("leg_l0",
                CubeListBuilder.create()
                        .texOffs(48, 77).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(60, 62).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(11f, 18f, -7f));
        root.addOrReplaceChild("leg_l1",
                CubeListBuilder.create()
                        .texOffs(48, 77).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(60, 62).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(11f, 18f, -2f));
        root.addOrReplaceChild("leg_l2",
                CubeListBuilder.create()
                        .texOffs(48, 77).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(60, 62).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(11f, 18f, 3f));
        root.addOrReplaceChild("leg_l3",
                CubeListBuilder.create()
                        .texOffs(48, 77).addBox(0f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(60, 62).addBox(9f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(11f, 18f, 8f));
        root.addOrReplaceChild("eye_r",
                CubeListBuilder.create()
                        .texOffs(32, 77).addBox(-1f, -5f, -1f, 2f, 5f, 2f)
                        .texOffs(0, 77).addBox(-2f, -9f, -2f, 4f, 4f, 4f),
                PartPose.offset(-5f, 10f, -8f));
        root.addOrReplaceChild("arm_r",
                CubeListBuilder.create()
                        .texOffs(36, 28).addBox(-2f, -2f, -12f, 4f, 4f, 12f)
                        .texOffs(84, 0).addBox(-4f, -4f, -22f, 8f, 8f, 10f),
                PartPose.offset(-13f, 15f, -6f));
        root.addOrReplaceChild("finger_up_r",
                CubeListBuilder.create()
                        .texOffs(68, 28).addBox(-2f, -4f, -12f, 4f, 4f, 12f),
                PartPose.offset(-13f, 15f, -28f));
        root.addOrReplaceChild("finger_low_r",
                CubeListBuilder.create()
                        .texOffs(0, 46).addBox(-2f, 0f, -12f, 4f, 4f, 12f),
                PartPose.offset(-13f, 15f, -28f));
        root.addOrReplaceChild("leg_r0",
                CubeListBuilder.create()
                        .texOffs(24, 85).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(92, 62).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-11f, 18f, -7f));
        root.addOrReplaceChild("leg_r1",
                CubeListBuilder.create()
                        .texOffs(24, 85).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(92, 62).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-11f, 18f, -2f));
        root.addOrReplaceChild("leg_r2",
                CubeListBuilder.create()
                        .texOffs(24, 85).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(92, 62).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-11f, 18f, 3f));
        root.addOrReplaceChild("leg_r3",
                CubeListBuilder.create()
                        .texOffs(24, 85).addBox(-10f, -1f, -1f, 10f, 2f, 2f)
                        .texOffs(92, 62).addBox(-11f, -1f, -1f, 2f, 7f, 2f),
                PartPose.offset(-11f, 18f, 8f));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        fingerUpL.xRot = -(0.12f + (Mth.sin(t * 0.12f) + 1.0f) * 0.22f);
        fingerUpR.xRot = -(0.12f + (Mth.sin(t * 0.12f + 1.5f) + 1.0f) * 0.22f);
        eyeL.yRot = Mth.sin(t * 0.07f) * 0.25f;
        eyeR.yRot = -Mth.sin(t * 0.07f) * 0.25f;
        ModelPart[] legsL = {legL0, legL1, legL2, legL3};
        ModelPart[] legsR = {legR0, legR1, legR2, legR3};
        for (int i = 0; i < 4; i++) {
            legsL[i].zRot = 0.15f + Mth.cos(p * 0.9f + i * 0.9f) * 0.35f * sp;
            legsR[i].zRot = -(0.15f + Mth.cos(p * 0.9f + i * 0.9f + 3.14f) * 0.35f * sp);
        }
    }
}
