package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class PollueloModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "polluelo"), "main");

    private final ModelPart wingL;
    private final ModelPart wingR;
    private final ModelPart legL;
    private final ModelPart legR;
    private final ModelPart stick;

    public PollueloModel(ModelPart root) {
        super(root);
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
        this.stick = root.getChild("stick");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 20).addBox(-5f, -11f, -4f, 10f, 10f, 8f)
                        .texOffs(0, 38).addBox(-3f, -9f, -5f, 6f, 7f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(8, 0).addBox(-6f, -19f, -5f, 12f, 9f, 10f)
                        .texOffs(46, 38).addBox(-1f, -14f, -7f, 2f, 2f, 2f)
                        .texOffs(14, 38).addBox(-5f, -21f, -2f, 2f, 3f, 2f)
                        .texOffs(22, 38).addBox(3f, -21f, -2f, 2f, 3f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("wing_l",
                CubeListBuilder.create()
                        .texOffs(36, 20).addBox(0f, 0f, -2f, 2f, 8f, 5f),
                PartPose.offset(5f, 13f, 0f));
        root.addOrReplaceChild("wing_r",
                CubeListBuilder.create()
                        .texOffs(50, 20).addBox(-2f, 0f, -2f, 2f, 8f, 5f),
                PartPose.offset(-5f, 13f, 0f));
        root.addOrReplaceChild("leg_l",
                CubeListBuilder.create()
                        .texOffs(30, 38).addBox(-1f, 0f, -1f, 2f, 3f, 2f),
                PartPose.offset(2f, 21f, 0f));
        root.addOrReplaceChild("leg_r",
                CubeListBuilder.create()
                        .texOffs(30, 38).addBox(-1f, 0f, -1f, 2f, 3f, 2f),
                PartPose.offset(-2f, 21f, 0f));
        root.addOrReplaceChild("stick",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1f, -18f, -1f, 2f, 18f, 2f)
                        .texOffs(0, 46).addBox(1f, -14f, -1f, 4f, 2f, 2f),
                PartPose.offset(-8f, 20f, -3f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        legL.xRot = Mth.cos(p * 1.1f) * 0.9f * sp;
        legR.xRot = Mth.cos(p * 1.1f + 3.14f) * 0.9f * sp;
        float flap = 0.1f + (Mth.sin(t * 0.5f) + 1.0f) * 0.2f;
        wingL.zRot = -flap;
        wingR.zRot = flap;
        stick.zRot = 0.3f + Mth.sin(t * 0.1f) * 0.05f;
        float sw = Anim.strike(state);
        stick.xRot -= sw * 1.6f;
        wingL.zRot -= Math.max(0.0f, sw) * 0.5f;
        wingR.zRot += Math.max(0.0f, sw) * 0.5f;
        this.root().y = -Anim.hop(state, 1.1f) * 1.2f;
        this.root().xRot = sw * 0.2f;
    }
}
