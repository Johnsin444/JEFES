package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class PollueloModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "polluelo"), "main");

    private final ModelPart wingL;
    private final ModelPart wingR;
    private final ModelPart legL;
    private final ModelPart legR;

    public PollueloModel(ModelPart root) {
        super(root);
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(36, 0).addBox(-4f, -11f, -3f, 8f, 8f, 6f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-5f, -18f, -4f, 10f, 7f, 8f)
                        .texOffs(40, 15).addBox(-1f, -13f, -6f, 2f, 2f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("wing_l",
                CubeListBuilder.create()
                        .texOffs(0, 15).addBox(0f, 0f, -2f, 2f, 7f, 4f),
                PartPose.offset(4f, 14f, 0f));
        root.addOrReplaceChild("wing_r",
                CubeListBuilder.create()
                        .texOffs(12, 15).addBox(-2f, 0f, -2f, 2f, 7f, 4f),
                PartPose.offset(-4f, 14f, 0f));
        root.addOrReplaceChild("leg_l",
                CubeListBuilder.create()
                        .texOffs(24, 15).addBox(-1f, 0f, -1f, 2f, 3f, 2f),
                PartPose.offset(2f, 21f, 0f));
        root.addOrReplaceChild("leg_r",
                CubeListBuilder.create()
                        .texOffs(24, 15).addBox(-1f, 0f, -1f, 2f, 3f, 2f),
                PartPose.offset(-2f, 21f, 0f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        legL.xRot = Mth.cos(p * 1.1f) * 0.9f * sp;
        legR.xRot = Mth.cos(p * 1.1f + 3.14f) * 0.9f * sp;
        float flap = 0.1f + (Mth.sin(t * 0.5f) + 1.0f) * 0.2f;
        wingL.zRot = -flap;
        wingR.zRot = flap;
    }
}
