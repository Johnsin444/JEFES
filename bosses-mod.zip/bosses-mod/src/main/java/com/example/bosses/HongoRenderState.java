package com.example.bosses;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class HongoRenderState extends LivingEntityRenderState {
}
