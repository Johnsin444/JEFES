package com.example.bosses;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class HongoRenderState extends LivingEntityRenderState {
    /** Progreso del golpe (0..1). Minecraft 26.3 ya no lo trae en el estado de render. */
    public float attackTime;
}
