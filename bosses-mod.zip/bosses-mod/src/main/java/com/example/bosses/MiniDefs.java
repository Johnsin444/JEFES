package com.example.bosses;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;

/** GENERADO: definiciones de todos los mini enemigos (modelo, hitbox, estadisticas y efecto al golpear). */
public final class MiniDefs {
    private MiniDefs() {}

    /** familia: 0 hongo, 1 cangrejo, 2 espectro, 3 buho */
    public record Def(String id, int family, float width, float height, double health, double damage, double speed,
                      Holder<MobEffect> effect, int effectTicks) {}

    public static final Def[] ALL = {
        new Def("hongo_mini", 0, 0.5f, 1.2f, 24.0, 4.0, 0.28, null, 0),
        new Def("hongo_nieves", 0, 0.7f, 1.8f, 44.0, 7.0, 0.27, MobEffects.SLOWNESS, 80),
        new Def("hongo_profundo", 0, 0.7f, 1.8f, 48.0, 8.0, 0.27, MobEffects.MINING_FATIGUE, 100),
        new Def("hongo_lunar", 0, 0.7f, 1.8f, 46.0, 8.0, 0.28, MobEffects.BLINDNESS, 40),
        new Def("cangrejito", 1, 1.1f, 0.7f, 20.0, 5.0, 0.3, null, 0),
        new Def("cangrejo", 1, 1.1f, 0.7f, 26.0, 4.0, 0.28, null, 0),
        new Def("cangrejo_nieves", 1, 1.1f, 0.9f, 44.0, 7.0, 0.26, MobEffects.SLOWNESS, 80),
        new Def("cangrejo_profundo", 1, 1.1f, 0.9f, 50.0, 8.0, 0.26, MobEffects.MINING_FATIGUE, 100),
        new Def("cangrejo_lunar", 1, 1.1f, 0.9f, 48.0, 8.0, 0.27, MobEffects.BLINDNESS, 40),
        new Def("fantasmita", 2, 0.5f, 1.1f, 18.0, 4.0, 0.28, null, 0),
        new Def("espectro_hielo", 2, 0.7f, 1.8f, 42.0, 7.0, 0.27, MobEffects.SLOWNESS, 80),
        new Def("espectro_abismo", 2, 0.7f, 1.9f, 48.0, 8.0, 0.27, MobEffects.WEAKNESS, 100),
        new Def("espectro_lunar", 2, 0.7f, 1.8f, 46.0, 8.0, 0.28, MobEffects.BLINDNESS, 40),
        new Def("espectro_coralino", 2, 0.6f, 1.8f, 40.0, 7.0, 0.27, MobEffects.POISON, 60),
        new Def("polluelo", 3, 0.5f, 1.2f, 18.0, 4.0, 0.32, null, 0),
        new Def("buho_helado", 3, 0.7f, 1.9f, 44.0, 7.0, 0.28, MobEffects.SLOWNESS, 80),
        new Def("buho_abisal", 3, 0.7f, 1.9f, 48.0, 8.0, 0.28, MobEffects.WEAKNESS, 100),
        new Def("buho_lunar", 3, 0.7f, 1.9f, 46.0, 8.0, 0.29, MobEffects.BLINDNESS, 40),
    };

    private static final Map<String, Def> BY_ID = new HashMap<>();

    static {
        for (Def d : ALL) BY_ID.put(d.id(), d);
    }

    public static Def get(String id) {
        return BY_ID.get(id);
    }
}
