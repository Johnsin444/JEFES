package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class EspectroFaroModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "espectro_faro"), "main");

    private final ModelPart arm;
    private final ModelPart lantern;

    public EspectroFaroModel(ModelPart root) {
        super(root);
        this.arm = root.getChild("arm");
        this.lantern = root.getChild("lantern");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-7f, -26f, -5f, 14f, 20f, 10f)
                        .texOffs(52, 30).addBox(-7f, -6f, -5f, 3f, 6f, 10f)
                        .texOffs(26, 30).addBox(-4f, -8f, -5f, 3f, 8f, 10f)
                        .texOffs(0, 49).addBox(-1f, -5f, -5f, 3f, 5f, 10f)
                        .texOffs(0, 30).addBox(2f, -9f, -5f, 3f, 9f, 10f)
                        .texOffs(78, 30).addBox(5f, -6f, -5f, 2f, 6f, 10f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("hood",
                CubeListBuilder.create()
                        .texOffs(48, 0).addBox(-8f, -36f, -7f, 16f, 10f, 14f)
                        .texOffs(50, 49).addBox(-5f, -41f, -4f, 10f, 5f, 8f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("face",
                CubeListBuilder.create()
                        .texOffs(86, 49).addBox(-5f, -34f, -8f, 10f, 6f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("arm",
                CubeListBuilder.create()
                        .texOffs(102, 30).addBox(-2f, 0f, -2f, 4f, 12f, 4f),
                PartPose.offset(9f, 0f, 0f));
        root.addOrReplaceChild("lantern",
                CubeListBuilder.create()
                        .texOffs(26, 49).addBox(-3f, -1f, -3f, 6f, 8f, 6f),
                PartPose.offset(9f, 7f, -10f));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float t = state.ageInTicks;
        this.root().y = Mth.sin(t * 0.1f) * 2.0f;
        arm.xRot = -1.0f;
        lantern.zRot = Mth.sin(t * 0.12f) * 0.18f;
    }
}
