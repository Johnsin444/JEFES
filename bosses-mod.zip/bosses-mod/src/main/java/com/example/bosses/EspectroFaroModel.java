package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class EspectroFaroModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "espectro_faro"), "main");

    private final ModelPart armL;
    private final ModelPart armR;
    private final ModelPart head;

    public EspectroFaroModel(ModelPart root) {
        super(root);
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.head = root.getChild("head");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("robe",
                CubeListBuilder.create()
                        .texOffs(56, 0).addBox(-10f, -14f, -7f, 20f, 12f, 14f)
                        .texOffs(32, 68).addBox(-10f, -2f, -7f, 20f, 2f, 14f)
                        .texOffs(0, 42).addBox(-8f, -30f, -5f, 16f, 16f, 10f)
                        .texOffs(72, 85).addBox(-8f, -17f, -5f, 16f, 2f, 10f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("chest",
                CubeListBuilder.create()
                        .texOffs(24, 98).addBox(-5f, -31f, -6f, 10f, 10f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("cloak",
                CubeListBuilder.create()
                        .texOffs(8, 0).addBox(-11f, -32f, 5f, 22f, 32f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("pauldrons",
                CubeListBuilder.create()
                        .texOffs(100, 68).addBox(-14f, -33f, -4f, 6f, 5f, 8f)
                        .texOffs(0, 85).addBox(8f, -33f, -4f, 6f, 5f, 8f)
                        .texOffs(32, 110).addBox(-15f, -35f, -1f, 2f, 2f, 2f)
                        .texOffs(40, 110).addBox(13f, -35f, -1f, 2f, 2f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(86, 42).addBox(-5f, -41f, -5f, 10f, 10f, 10f)
                        .texOffs(28, 85).addBox(-6f, -44f, -5f, 12f, 3f, 10f)
                        .texOffs(110, 98).addBox(-6f, -48f, -5f, 2f, 4f, 2f)
                        .texOffs(94, 98).addBox(-1f, -49f, -5f, 2f, 5f, 2f)
                        .texOffs(118, 98).addBox(4f, -48f, -5f, 2f, 4f, 2f)
                        .texOffs(0, 110).addBox(-6f, -48f, 3f, 2f, 4f, 2f)
                        .texOffs(102, 98).addBox(-1f, -49f, 3f, 2f, 5f, 2f)
                        .texOffs(8, 110).addBox(4f, -48f, 3f, 2f, 4f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("arm_l",
                CubeListBuilder.create()
                        .texOffs(0, 68).addBox(-2f, 0f, -2f, 4f, 13f, 4f)
                        .texOffs(46, 98).addBox(-2f, 13f, -2f, 4f, 4f, 4f),
                PartPose.offset(11f, -7f, 0f));
        root.addOrReplaceChild("arm_r",
                CubeListBuilder.create()
                        .texOffs(0, 68).addBox(-2f, 0f, -2f, 4f, 13f, 4f)
                        .texOffs(46, 98).addBox(-2f, 13f, -2f, 4f, 4f, 4f),
                PartPose.offset(-11f, -7f, 0f));
        root.addOrReplaceChild("scepter",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1f, -40f, -1f, 2f, 40f, 2f)
                        .texOffs(0, 98).addBox(-3f, -46f, -3f, 6f, 6f, 6f)
                        .texOffs(78, 98).addBox(-2f, -50f, -2f, 4f, 4f, 4f)
                        .texOffs(16, 110).addBox(-2f, -36f, -2f, 4f, 2f, 4f),
                PartPose.offset(11f, 24f, -11f));
        root.addOrReplaceChild("shield",
                CubeListBuilder.create()
                        .texOffs(52, 42).addBox(-7f, -30f, -2f, 14f, 20f, 3f),
                PartPose.offset(-14f, 24f, -9f));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float t = state.ageInTicks;
        this.root().y = Mth.sin(t * 0.1f) * 2.0f;
        armL.xRot = -0.7f + Mth.sin(t * 0.08f) * 0.05f;
        armR.xRot = -0.5f + Mth.sin(t * 0.08f + 1.0f) * 0.05f;
        head.yRot = Mth.sin(t * 0.05f) * 0.15f;
    }
}
