package com.example.bosses;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Dungeons procedurales bajo tierra, repartidas por el mundo como aldeas (1 candidata por region de 32x32 chunks).
 * Cada tema (hongo, cangrejo, espectro, buho) tiene decoracion y progresion propias. En superficie queda un monton de escombros.
 * Se construyen por fases (una por tick) y el bloque centinela de bedrock se coloca al final.
 */
public final class DungeonGen {
    private DungeonGen() {}

    static final int SPACING = 32;     // chunks por region
    static final int SIZE = 64;        // huella 64x64 (4x4 chunks)

    record Task(ServerLevel level, Object owner, Runnable run) {}

    private static final ArrayDeque<Task> QUEUE = new ArrayDeque<>();
    private static final Set<Long> BUSY = new HashSet<>();
    private static final Set<Long> SKIP = new HashSet<>();

    /** Tema: prefijo de bloques, jefe, loot y minis por nivel de progresion. */
    record Theme(String id, String prefix, String boss, String loot, String[][] tiers) {}

    static final Theme[] THEMES = {
        new Theme("hongo", "sporestone", "bosses:rey_hongo", "bosses:chests/hongo_dungeon",
                new String[][]{{"hongo_mini"}, {"hongo_nieves"}, {"hongo_profundo"}, {"hongo_lunar"}}),
        new Theme("crab", "coralshell", "bosses:cangrejo_coloso", "bosses:chests/crab_dungeon",
                new String[][]{{"cangrejito", "cangrejo"}, {"cangrejo_nieves"}, {"cangrejo_profundo"}, {"cangrejo_lunar"}}),
        new Theme("ghost", "wraithstone", "bosses:espectro_faro", "bosses:chests/ghost_dungeon",
                new String[][]{{"fantasmita"}, {"espectro_hielo"}, {"espectro_abismo", "espectro_coralino"}, {"espectro_lunar"}}),
        new Theme("owl", "moonslate", "bosses:buho_eclipse", "bosses:chests/owl_dungeon",
                new String[][]{{"polluelo"}, {"buho_helado"}, {"buho_abisal"}, {"buho_lunar"}}),
    };

    // salas locales: x0,z0,x1,z1,alto,nivel
    static final int[][] ROOMS = {
        {2, 2, 16, 16, 7, 0}, {24, 2, 38, 16, 7, 1}, {46, 2, 60, 16, 7, 2}, {46, 22, 60, 30, 7, 3}, {22, 36, 60, 61, 14, 3}};
    // pasillos: de (x,z) a (x,z) a lo largo de un eje
    static final int[][] CORRIDORS = {{16, 9, 24, 9}, {38, 9, 46, 9}, {53, 16, 53, 22}, {53, 30, 53, 36}};

    public static void init() {
        ServerTickEvents.END_LEVEL_TICK.register(DungeonGen::tick);
    }

    private static void tick(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD) return;
        Task head = QUEUE.peek();
        if (head != null && head.level() == level) {
            QUEUE.poll();
            try {
                head.run().run();
            } catch (Exception e) {
                BossesMod.LOGGER.warn("Fallo construyendo dungeon", e);
            }
        }
        if (level.getGameTime() % 40 != 0 || !QUEUE.isEmpty()) return;
        for (ServerPlayer p : level.players()) {
            int prx = Math.floorDiv(p.chunkPosition().x(), SPACING), prz = Math.floorDiv(p.chunkPosition().z(), SPACING);
            for (int rx = prx - 1; rx <= prx + 1; rx++)
                for (int rz = prz - 1; rz <= prz + 1; rz++) consider(level, p, rx, rz);
        }
    }

    private static long mix(long seed, int rx, int rz) {
        long h = seed ^ (rx * 341873128712L) ^ (rz * 132897987541L) ^ 0x5DEECE66DL;
        h ^= h >>> 29; h *= 0xBF58476D1CE4E5B9L; h ^= h >>> 32;
        return h;
    }

    private static void consider(ServerLevel level, ServerPlayer p, int rx, int rz) {
        long key = ((long) rx << 32) ^ (rz & 0xffffffffL);
        if (BUSY.contains(key) || SKIP.contains(key)) return;
        RandomSource r = RandomSource.create(mix(level.getSeed(), rx, rz));
        if (r.nextFloat() > 0.8f) { SKIP.add(key); return; }
        int cx = rx * SPACING + 2 + r.nextInt(SPACING - 8), cz = rz * SPACING + 2 + r.nextInt(SPACING - 8);
        Theme theme = THEMES[r.nextInt(THEMES.length)];
        int dx = Math.abs(p.chunkPosition().x() - cx), dz = Math.abs(p.chunkPosition().z() - cz);
        if (dx > 8 || dz > 8) return;
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (!level.hasChunk(cx + i, cz + j)) return;
        int ox = cx * 16, oz = cz * 16;
        int top = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, ox + 8, oz + 8) - 1;
        if (!level.getBlockState(new BlockPos(ox + 8, top, oz + 8)).getFluidState().isEmpty()) { SKIP.add(key); return; }
        int floorY = Math.max(level.getMinY() + 8, top - 26);
        if (top - floorY < 14) { SKIP.add(key); return; }
        BlockPos sentinel = new BlockPos(ox + 3, floorY - 3, oz + 3);
        if (level.getBlockState(sentinel).is(Blocks.BEDROCK)) { SKIP.add(key); return; }
        BUSY.add(key);
        new Build(level, theme, ox, floorY, oz, top, mix(level.getSeed(), rx, rz), key, sentinel).schedule();
    }

    // ------------------------------------------------------------------------------------------
    static final class Build {
        final ServerLevel level; final Theme th; final int ox, fy, oz, top; final RandomSource rnd; final long key; final BlockPos sentinel;

        Build(ServerLevel level, Theme th, int ox, int fy, int oz, int top, long seed, long key, BlockPos sentinel) {
            this.level = level; this.th = th; this.ox = ox; this.fy = fy; this.oz = oz; this.top = top;
            this.rnd = RandomSource.create(seed ^ 0x1234ABCDL); this.key = key; this.sentinel = sentinel;
        }

        void add(Runnable r) { QUEUE.add(new Task(level, this, r)); }

        boolean loaded() {
            int cx = ox >> 4, cz = oz >> 4;
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (!level.hasChunk(cx + i, cz + j)) return false;
            return true;
        }

        void guard(Runnable r) {
            add(() -> {
                if (!loaded()) { abort(); return; }
                r.run();
            });
        }

        void abort() {
            QUEUE.removeIf(t -> t.owner() == this);
            BUSY.remove(key);
            aborted = true;
        }
        boolean aborted = false;

        BlockState b(String s) { return ModBlocks.get(th.prefix() + "_" + s).defaultBlockState(); }

        void set(int lx, int ly, int lz, BlockState st) {
            level.setBlock(new BlockPos(ox + lx, fy + ly, oz + lz), st, 2);
        }

        void fill(int x0, int y0, int z0, int x1, int y1, int z1, BlockState st) {
            for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) set(x, y, z, st);
        }

        BlockState wall() {
            float f = rnd.nextFloat();
            return f < 0.68f ? b("bricks") : f < 0.92f ? b("cracked_bricks") : b("chiseled");
        }

        void shell(int x0, int z0, int x1, int z1, int h) {
            for (int x = x0 - 1; x <= x1 + 1; x++) for (int z = z0 - 1; z <= z1 + 1; z++) for (int y = -2; y <= h; y++) {
                boolean edge = x == x0 - 1 || x == x1 + 1 || z == z0 - 1 || z == z1 + 1 || y == -2 || y == h;
                if (edge) set(x, y, z, y == -1 || y == -2 ? floorBlock(x, z) : wall());
            }
        }

        BlockState floorBlock(int x, int z) {
            return ((x + z) & 1) == 0 && rnd.nextFloat() < 0.8f ? b("bricks") : rnd.nextFloat() < 0.4f ? b("cracked_bricks") : b("bricks");
        }

        void carve(int x0, int z0, int x1, int z1, int h) {
            fill(x0, 0, z0, x1, h - 1, z1, Blocks.AIR.defaultBlockState());
            for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) set(x, -1, z, floorBlock(x, z));
        }

        void schedule() {
            // fase 1: cascarones + tuneles
            guard(() -> {
                for (int[] r : ROOMS) shell(r[0], r[1], r[2], r[3], r[4]);
                for (int[] c : CORRIDORS) corridorShell(c);
            });
            // fase 2: vaciar
            guard(() -> {
                for (int[] r : ROOMS) carve(r[0], r[1], r[2], r[3], r[4]);
                for (int[] c : CORRIDORS) corridorCarve(c);
            });
            // fase 3..: decoracion por sala
            for (int i = 0; i < ROOMS.length; i++) {
                final int[] r = ROOMS[i];
                final int idx = i;
                guard(() -> decorate(r, idx));
            }
            guard(this::shaftAndMarker);
            guard(this::finish);
        }

        void corridorShell(int[] c) {
            int x0 = Math.min(c[0], c[2]), x1 = Math.max(c[0], c[2]), z0 = Math.min(c[1], c[3]), z1 = Math.max(c[1], c[3]);
            boolean alongX = c[1] == c[3];
            if (alongX) shell(x0, z0 - 1, x1, z1 + 1, 4); else shell(x0 - 1, z0, x1 + 1, z1, 4);
        }

        void corridorCarve(int[] c) {
            int x0 = Math.min(c[0], c[2]), x1 = Math.max(c[0], c[2]), z0 = Math.min(c[1], c[3]), z1 = Math.max(c[1], c[3]);
            boolean alongX = c[1] == c[3];
            if (alongX) carve(x0, z0 - 1, x1, z1 + 1, 4); else carve(x0 - 1, z0, x1 + 1, z1, 4);
            // lamparas del techo cada 4 bloques
            for (int t = 3; t < (alongX ? x1 - x0 : z1 - z0); t += 4) {
                if (alongX) set(x0 + t, 4, z0, b("lamp")); else set(x0, 4, z0 + t, b("lamp"));
            }
        }

        // ---- decoracion ----
        void decorate(int[] r, int idx) {
            int x0 = r[0], z0 = r[1], x1 = r[2], z1 = r[3], h = r[4], tier = r[5];
            boolean arena = idx == ROOMS.length - 1;
            int cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
            BlockState pillar = b("pillar").setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y);
            // pilares en esquinas
            for (int[] p : new int[][]{{x0 + 1, z0 + 1}, {x1 - 1, z0 + 1}, {x0 + 1, z1 - 1}, {x1 - 1, z1 - 1}})
                for (int y = 0; y < h; y++) set(p[0], y, p[1], pillar);
            // lamparas de techo
            for (int dx : new int[]{-4, 4}) for (int dz : new int[]{-4, 4}) {
                if (cx + dx > x0 && cx + dx < x1 && cz + dz > z0 && cz + dz < z1) set(cx + dx, h, cz + dz, b("lamp"));
            }
            // emblema central
            fill(cx - 1, -1, cz - 1, cx + 1, -1, cz + 1, b("chiseled"));
            themeDecor(x0, z0, x1, z1, h, cx, cz, arena);
            String[] minis = th.tiers()[tier];
            if (arena) {
                for (int[] p : new int[][]{{x0 + 3, z0 + 3}, {x1 - 3, z0 + 3}, {x0 + 3, z1 - 3}, {x1 - 3, z1 - 3}})
                    spawner(p[0], p[1], th.tiers()[3], 3, 8);
                spawner(cx - 6, cz, th.tiers()[2], 2, 6);
                spawner(cx + 6, cz, th.tiers()[2], 2, 6);
                chest(x0 + 1, z1 - 1, Direction.NORTH);
                chest(x1 - 1, z1 - 1, Direction.NORTH);
                chest(cx, z1 - 1, Direction.NORTH);
            } else {
                spawner(x0 + 3, z1 - 3, minis, 2, 6);
                spawner(x1 - 3, z0 + 3, minis, 2, 6);
                chest(cx, z1 - 1, Direction.NORTH);
                if (tier >= 2) chest(x0 + 1, cz, Direction.EAST);
            }
        }

        void themeDecor(int x0, int z0, int x1, int z1, int h, int cx, int cz, boolean arena) {
            switch (th.id()) {
                case "hongo" -> {
                    for (int i = 0; i < (x1 - x0) * (z1 - z0) / 7; i++) {
                        int x = x0 + rnd.nextInt(x1 - x0 + 1), z = z0 + rnd.nextInt(z1 - z0 + 1);
                        if (rnd.nextFloat() < 0.5f) set(x, -1, z, Blocks.MOSS_BLOCK.defaultBlockState());
                        else if (isAir(x, 0, z)) set(x, 0, z, (rnd.nextBoolean() ? Blocks.RED_MUSHROOM : Blocks.BROWN_MUSHROOM).defaultBlockState());
                    }
                    for (int[] p : new int[][]{{cx - 4, cz - 4}, {cx + 4, cz + 4}}) {
                        if (p[0] <= x0 + 1 || p[0] >= x1 - 1 || p[1] <= z0 + 1 || p[1] >= z1 - 1) continue;
                        for (int y = 0; y < h - 2; y++) set(p[0], y, p[1], Blocks.MUSHROOM_STEM.defaultBlockState());
                        fill(p[0] - 2, h - 2, p[1] - 2, p[0] + 2, h - 2, p[1] + 2, Blocks.RED_MUSHROOM_BLOCK.defaultBlockState());
                        set(p[0], h - 3, p[1], Blocks.SHROOMLIGHT.defaultBlockState());
                    }
                }
                case "crab" -> {
                    int pw = arena ? 4 : 2;
                    fill(cx - pw - 2, -1, cz - pw - 2, cx + pw + 2, -1, cz + pw + 2, Blocks.SAND.defaultBlockState());
                    fill(cx - pw, -1, cz - pw, cx + pw, -1, cz + pw, Blocks.WATER.defaultBlockState());
                    for (int i = 0; i < 6; i++) {
                        int x = x0 + 2 + rnd.nextInt(x1 - x0 - 3), z = z0 + 2 + rnd.nextInt(z1 - z0 - 3);
                        if (isAir(x, 0, z) && !(Math.abs(x - cx) <= pw && Math.abs(z - cz) <= pw))
                            set(x, 0, z, (rnd.nextBoolean() ? Blocks.TUBE_CORAL_BLOCK : Blocks.BRAIN_CORAL_BLOCK).defaultBlockState());
                    }
                    for (int[] p : new int[][]{{x0 + 1, cz}, {x1 - 1, cz}}) set(p[0], h - 1, p[1], Blocks.SEA_LANTERN.defaultBlockState());
                }
                case "ghost" -> {
                    for (int i = 0; i < (x1 - x0) * (z1 - z0) / 6; i++) {
                        int x = x0 + rnd.nextInt(x1 - x0 + 1), z = z0 + rnd.nextInt(z1 - z0 + 1);
                        float f = rnd.nextFloat();
                        if (f < 0.5f) set(x, -1, z, (rnd.nextBoolean() ? Blocks.SOUL_SAND : Blocks.SOUL_SOIL).defaultBlockState());
                        else if (f < 0.7f && isAir(x, 0, z)) set(x, 0, z, Blocks.COBWEB.defaultBlockState());
                    }
                    for (int[] p : new int[][]{{cx - 5, cz}, {cx + 5, cz}, {cx, cz - 5}, {cx, cz + 5}}) {
                        if (p[0] > x0 && p[0] < x1 && p[1] > z0 && p[1] < z1 && isAir(p[0], h - 1, p[1]))
                            set(p[0], h - 1, p[1], Blocks.SOUL_LANTERN.defaultBlockState().setValue(net.minecraft.world.level.block.LanternBlock.HANGING, true));
                    }
                }
                default -> { // owl: biblioteca lunar con tarima
                    for (int x = x0 + 2; x <= x1 - 2; x += 2) {
                        set(x, 0, z0, Blocks.BOOKSHELF.defaultBlockState());
                        set(x, 1, z0, Blocks.BOOKSHELF.defaultBlockState());
                    }
                    BlockState slab = b("bricks_slab").setValue(SlabBlock.TYPE, SlabType.BOTTOM);
                    fill(cx - 3, 0, cz - 3, cx + 3, 0, cz + 3, slab);
                    for (int i = -3; i <= 3; i++) {
                        set(cx + i, 0, cz - 4, stair(Direction.SOUTH));
                        set(cx + i, 0, cz + 4, stair(Direction.NORTH));
                    }
                    for (int[] p : new int[][]{{cx - 2, cz - 2}, {cx + 2, cz + 2}, {cx - 2, cz + 2}, {cx + 2, cz - 2}}) set(p[0], 1, p[1], Blocks.CANDLE.defaultBlockState());
                    for (int[] p : new int[][]{{cx - 5, cz}, {cx + 5, cz}}) {
                        if (p[0] > x0 && p[0] < x1) { set(p[0], h - 1, p[1], Blocks.IRON_BARS.defaultBlockState()); set(p[0], h - 2, p[1], Blocks.IRON_BARS.defaultBlockState()); set(p[0], h - 3, p[1], b("lamp")); }
                    }
                }
            }
        }

        BlockState stair(Direction facing) {
            return b("bricks_stairs").setValue(StairBlock.FACING, facing);
        }

        boolean isAir(int lx, int ly, int lz) {
            return level.getBlockState(new BlockPos(ox + lx, fy + ly, oz + lz)).isAir();
        }

        void command(String cmd) {
            CommandSourceStack src = level.getServer().createCommandSourceStack().withLevel(level).withSuppressedOutput();
            level.getServer().getCommands().performPrefixedCommand(src, cmd);
        }

        void spawner(int lx, int lz, String[] minis, int count, int maxNearby) {
            int x = ox + lx, y = fy, z = oz + lz;
            set(lx, -1, lz, b("chiseled"));
            StringBuilder pot = new StringBuilder();
            for (String m : minis) {
                if (pot.length() > 0) pot.append(',');
                pot.append("{weight:1,data:{entity:{id:\"bosses:").append(m).append("\"}}}");
            }
            command("setblock " + x + " " + y + " " + z + " minecraft:spawner{SpawnData:{entity:{id:\"bosses:" + minis[0]
                    + "\"}},SpawnPotentials:[" + pot + "],RequiredPlayerRange:14,SpawnRange:4,MinSpawnDelay:200,MaxSpawnDelay:500,MaxNearbyEntities:"
                    + maxNearby + ",SpawnCount:" + count + "}");
        }

        void chest(int lx, int lz, Direction facing) {
            command("setblock " + (ox + lx) + " " + fy + " " + (oz + lz) + " minecraft:chest[facing=" + facing.getName()
                    + "]{LootTable:\"" + th.loot() + "\"}");
        }

        // ---- entrada con escombros ----
        void shaftAndMarker() {
            int sx = 8, sz = 9; // dentro de la sala 0
            int topWorldY = top;
            BlockState rubble = b("rubble");
            // pozo 3x3 tapado de escombros desde el techo de la sala hasta la superficie
            for (int y = 7; y <= topWorldY - fy; y++)
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                    BlockPos p = new BlockPos(ox + sx + dx, fy + y, oz + sz + dz);
                    level.setBlock(p, rubble, 2);
                }
            // monton de superficie
            for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 5.2 || rnd.nextFloat() < d / 7.5) continue;
                int wx = ox + sx + dx, wz = oz + sz + dz;
                int gy = ground(wx, wz);
                if (gy == Integer.MIN_VALUE) continue;
                level.setBlock(new BlockPos(wx, gy, wz), rubble, 2);
                if (d < 3.2 && rnd.nextFloat() < 0.75f) level.setBlock(new BlockPos(wx, gy + 1, wz), rubble, 2);
                if (d < 1.8 && rnd.nextFloat() < 0.6f) level.setBlock(new BlockPos(wx, gy + 2, wz), rubble, 2);
            }
            // restos de columnas y bloques rotos
            for (int i = 0; i < 4; i++) {
                double a = rnd.nextDouble() * Math.PI * 2, d = 3.5 + rnd.nextDouble() * 1.5;
                int wx = ox + sx + (int) Math.round(Math.cos(a) * d), wz = oz + sz + (int) Math.round(Math.sin(a) * d);
                int gy = ground(wx, wz);
                if (gy == Integer.MIN_VALUE) continue;
                int hgt = 1 + rnd.nextInt(3);
                for (int y = 1; y <= hgt; y++)
                    level.setBlock(new BlockPos(wx, gy + y, wz), b("pillar").setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y), 2);
                if (rnd.nextBoolean()) level.setBlock(new BlockPos(wx + 1, gy + 1, wz), b("cracked_bricks"), 2);
                else level.setBlock(new BlockPos(wx, gy + hgt + 1, wz), b("bricks_slab").setValue(SlabBlock.TYPE, SlabType.BOTTOM), 2);
            }
        }

        /** Y del suelo real (ultimo bloque solido) o MIN_VALUE si hay un tronco/agua. */
        int ground(int wx, int wz) {
            int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, wx, wz) + 3;
            for (int i = 0; i < 40; i++, y--) {
                BlockState s = level.getBlockState(new BlockPos(wx, y, wz));
                if (s.isAir() || s.is(BlockTags.LEAVES) || s.canBeReplaced()) continue;
                if (s.is(BlockTags.LOGS) || !s.getFluidState().isEmpty()) return Integer.MIN_VALUE;
                return y;
            }
            return Integer.MIN_VALUE;
        }

        void finish() {
            int[] a = ROOMS[ROOMS.length - 1];
            int cx = (a[0] + a[2]) / 2, cz = (a[1] + a[3]) / 2;
            command("summon " + th.boss() + " " + (ox + cx) + " " + fy + " " + (oz + cz) + " {PersistenceRequired:1b}");
            level.setBlock(sentinel, Blocks.BEDROCK.defaultBlockState(), 2);
            BUSY.remove(key);
            SKIP.add(key);
        }
    }
}
