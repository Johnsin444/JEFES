package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class FantasmitaModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "fantasmita"), "main");



    public FantasmitaModel(ModelPart root) {
        super(root);

    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-4f, -10f, -3f, 8f, 8f, 6f)
                        .texOffs(18, 14).addBox(-4f, -2f, -3f, 3f, 2f, 6f)
                        .texOffs(0, 14).addBox(-1f, -3f, -3f, 3f, 3f, 6f)
                        .texOffs(36, 14).addBox(2f, -1f, -3f, 2f, 1f, 6f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("hood",
                CubeListBuilder.create()
                        .texOffs(28, 0).addBox(-5f, -16f, -4f, 10f, 6f, 8f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("face",
                CubeListBuilder.create()
                        .texOffs(0, 23).addBox(-3f, -14f, -5f, 6f, 3f, 1f),
                PartPose.offset(0f, 24f, 0f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        this.root().y = Mth.sin(state.ageInTicks * 0.15f) * 1.5f - 2.0f;
    }
}
