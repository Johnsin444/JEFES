package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class FantasmitaModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "fantasmita"), "main");

    private final ModelPart sword;

    public FantasmitaModel(ModelPart root) {
        super(root);
        this.sword = root.getChild("sword");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-5f, -14f, -4f, 10f, 10f, 8f)
                        .texOffs(42, 0).addBox(-5f, -4f, -4f, 3f, 4f, 8f)
                        .texOffs(24, 18).addBox(-2f, -4f, -4f, 3f, 3f, 8f)
                        .texOffs(0, 18).addBox(1f, -4f, -4f, 4f, 4f, 8f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("arm_l",
                CubeListBuilder.create()
                        .texOffs(46, 18).addBox(-1f, 0f, -1f, 3f, 6f, 3f),
                PartPose.offset(6f, 12f, 0f));
        root.addOrReplaceChild("sword",
                CubeListBuilder.create()
                        .texOffs(36, 0).addBox(-1f, -14f, -1f, 2f, 12f, 1f)
                        .texOffs(8, 30).addBox(-3f, -3f, -1f, 6f, 1f, 2f)
                        .texOffs(0, 30).addBox(-1f, -2f, -1f, 2f, 3f, 2f),
                PartPose.offset(-7f, 18f, -4f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float t = state.ageInTicks;
        this.root().y = Mth.sin(t * 0.15f) * 1.5f - 2.0f;
        sword.xRot = -0.5f + Mth.sin(t * 0.15f) * 0.15f;
    }
}
