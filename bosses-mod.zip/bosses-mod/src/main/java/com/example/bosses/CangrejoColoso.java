package com.example.bosses;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class CangrejoColoso extends BossBase {
    private int smashCooldown = 80;
    private int shellCooldown = 200;
    private int leapCooldown = 200;
    private int leapTicks = -1;
    private int summonCooldown = 450;

    public CangrejoColoso(EntityType<? extends CangrejoColoso> type, Level level) {
        super(type, level, "entity.bosses.cangrejo_coloso", BossEvent.BossBarColor.YELLOW);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 400.0)
                .add(Attributes.MOVEMENT_SPEED, 0.2)
                .add(Attributes.ATTACK_DAMAGE, 14.0)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9)
                .add(Attributes.ARMOR, 10.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.7));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 16.0f));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void abilities(ServerLevel level) {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double dist = distanceToSqr(target);
        Vec3 toTarget = target.position().subtract(position());
        Vec3 dir = toTarget.lengthSqr() < 1.0E-4 ? Vec3.ZERO : toTarget.normalize();

        // Escudo de concha: mas resistencia cuando esta herido
        if (--shellCooldown <= 0) {
            shellCooldown = cd(300);
            if (isPhaseTwo() || getHealth() < getMaxHealth() * 0.7f) {
                addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, 2));
                level.sendParticles(ParticleTypes.SPLASH, getX(), getY() + 1.0, getZ(), 40, 1.2, 0.8, 1.2, 0.1);
            }
        }

        // Pinzazo: rompe bloques blandos delante de el
        if (--smashCooldown <= 0 && dist < 6 * 6) {
            smashCooldown = cd(100);
            playSound(ModSounds.CANGREJO_COLOSO_ATTACK, 2.0f, 1.0f);
            BlockPos center = blockPosition().offset((int) Math.round(dir.x * 2), 0, (int) Math.round(dir.z * 2));
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = 0; dy <= 2; dy++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        BlockPos p = center.offset(dx, dy, dz);
                        BlockState state = level.getBlockState(p);
                        if (state.isAir() || level.getBlockEntity(p) != null) continue;
                        float hardness = state.getDestroySpeed(level, p);
                        if (hardness >= 0 && hardness <= 3.5f) level.destroyBlock(p, true);
                    }
                }
            }
        }

        if (isPhaseTwo() && --summonCooldown <= 0) {
            summonCooldown = 500;
            summonMinis(level, l -> new SimpleMini(BossesMod.CANGREJITO, l), 2, 9);
        }

        // Salto con oleada de agua
        if (leapTicks >= 0) {
            leapTicks++;
            if (leapTicks > 8 && onGround()) {
                leapTicks = -1;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class,
                        getBoundingBox().inflate(7.0), x -> x != this && !(x instanceof BossBase))) {
                    double dx = e.getX() - getX();
                    double dz = e.getZ() - getZ();
                    double len = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
                    e.push(dx / len * 1.4, 0.5, dz / len * 1.4);
                    e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 1));
                }
                level.sendParticles(ParticleTypes.SPLASH, getX(), getY() + 0.3, getZ(), 120, 3.5, 0.3, 3.5, 0.2);
            }
        } else if (--leapCooldown <= 0 && dist > 4 * 4 && dist < 16 * 16 && onGround()) {
            leapCooldown = cd(240);
            leapTicks = 0;
            setDeltaMovement(dir.x * 0.9, 0.85, dir.z * 0.9);
        }
    }


    @Override
    protected SoundEvent phaseSound() {
        return ModSounds.CANGREJO_COLOSO_PHASE;
    }

    @Override
    protected void onPhaseTwo(ServerLevel level) {
        summonMinis(level, l -> new SimpleMini(BossesMod.CANGREJITO, l), 4, 9);
    }

    @Override
    protected void applyPhaseTwoStats() {
        setBase(Attributes.ATTACK_DAMAGE, 14.0 * 1.3);
        setBase(Attributes.MOVEMENT_SPEED, 0.2 * 1.3);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.CANGREJO_COLOSO_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.CANGREJO_COLOSO_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.CANGREJO_COLOSO_DEATH;
    }
}
