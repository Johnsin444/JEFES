package com.example.bosses;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import com.geckolib.animatable.GeoEntity;
import com.geckolib.animatable.instance.AnimatableInstanceCache;
import com.geckolib.animatable.manager.AnimatableManager;
import com.geckolib.animation.AnimationController;
import com.geckolib.animation.RawAnimation;
import com.geckolib.animation.object.PlayState;
import com.geckolib.animation.state.AnimationTest;
import com.geckolib.util.GeckoLibUtil;

/** Mini enemigo con GeckoLib. Un solo tipo de clase para las 18 variantes: stats y efectos salen de {@link MiniDefs}. */
public class GeoMini extends Monster implements GeoEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("walk");

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private final MiniDefs.Def def;
    private int lastAttackStamp = 0;

    public GeoMini(EntityType<? extends GeoMini> type, Level level) {
        super(type, level);
        this.def = MiniDefs.get(BuiltInRegistries.ENTITY_TYPE.getKey(type).getPath());
    }

    public static AttributeSupplier.Builder createAttributes(MiniDefs.Def d) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, d.health())
                .add(Attributes.MOVEMENT_SPEED, d.speed())
                .add(Attributes.ATTACK_DAMAGE, d.damage())
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, d.health() > 40 ? 0.3 : 0.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1, true));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 10.0f));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level() instanceof ServerLevel) {
            int stamp = getLastHurtMobTimestamp();
            if (stamp != lastAttackStamp) {
                lastAttackStamp = stamp;
                triggerAnim("action", "attack");
                if (def != null && def.effect() != null && getLastHurtMob() instanceof LivingEntity victim) {
                    victim.addEffect(new MobEffectInstance(def.effect(), def.effectTicks(), 0));
                }
            }
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<GeoMini>("movement", 4,
                (AnimationTest<GeoMini> s) -> s.setAndContinue(s.isMoving() ? WALK : IDLE)));
        AnimationController<GeoMini> action = new AnimationController<GeoMini>("action", 2, s -> PlayState.STOP);
        action.triggerableAnim("attack", RawAnimation.begin().thenPlay("attack"));
        controllers.add(action);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    private int fam() {
        return def == null ? 0 : def.family();
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return switch (fam()) {
            case 1 -> ModSounds.CANGREJITO_AMBIENT;
            case 2 -> ModSounds.FANTASMITA_AMBIENT;
            case 3 -> ModSounds.POLLUELO_AMBIENT;
            default -> ModSounds.HONGO_MINI_AMBIENT;
        };
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return switch (fam()) {
            case 1 -> ModSounds.CANGREJITO_HURT;
            case 2 -> ModSounds.FANTASMITA_HURT;
            case 3 -> ModSounds.POLLUELO_HURT;
            default -> ModSounds.HONGO_MINI_HURT;
        };
    }

    @Override
    protected SoundEvent getDeathSound() {
        return switch (fam()) {
            case 1 -> ModSounds.CANGREJITO_DEATH;
            case 2 -> ModSounds.FANTASMITA_DEATH;
            case 3 -> ModSounds.POLLUELO_DEATH;
            default -> ModSounds.HONGO_MINI_DEATH;
        };
    }
}
