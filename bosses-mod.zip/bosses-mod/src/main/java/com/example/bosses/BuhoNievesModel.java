package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class BuhoNievesModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "buho_nieves"), "main");

    private final ModelPart armL;
    private final ModelPart armR;

    public BuhoNievesModel(ModelPart root) {
        super(root);
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(10, 0).addBox(-6f, -18f, -4f, 12f, 12f, 8f)
                        .texOffs(48, 32).addBox(-4f, -16f, -5f, 8f, 8f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(50, 0).addBox(-6f, -28f, -5f, 12f, 10f, 10f)
                        .texOffs(32, 32).addBox(-1f, -32f, -2f, 2f, 4f, 6f)
                        .texOffs(90, 32).addBox(-6f, -31f, -1f, 3f, 4f, 3f)
                        .texOffs(102, 32).addBox(3f, -31f, -1f, 3f, 4f, 3f)
                        .texOffs(114, 32).addBox(-1f, -22f, -8f, 3f, 4f, 3f)
                        .texOffs(0, 46).addBox(-5f, -26f, -6f, 10f, 4f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("arm_l",
                CubeListBuilder.create()
                        .texOffs(0, 32).addBox(-2f, 0f, -2f, 4f, 10f, 4f),
                PartPose.offset(8f, -4f, 0f));
        root.addOrReplaceChild("arm_r",
                CubeListBuilder.create()
                        .texOffs(0, 32).addBox(-2f, 0f, -2f, 4f, 10f, 4f),
                PartPose.offset(-8f, -4f, 0f));
        root.addOrReplaceChild("sword",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1f, -34f, -1f, 3f, 30f, 2f)
                        .texOffs(22, 46).addBox(-5f, -5f, -1f, 10f, 2f, 2f)
                        .texOffs(66, 32).addBox(-1f, -3f, -1f, 2f, 6f, 2f),
                PartPose.offset(-9f, 6f, -7f));
        root.addOrReplaceChild("shield",
                CubeListBuilder.create()
                        .texOffs(94, 0).addBox(-6f, -8f, -1f, 12f, 16f, 2f),
                PartPose.offset(11f, 6f, -8f));
        root.addOrReplaceChild("legs",
                CubeListBuilder.create()
                        .texOffs(74, 32).addBox(-4f, -6f, -2f, 2f, 6f, 2f)
                        .texOffs(82, 32).addBox(2f, -6f, -2f, 2f, 6f, 2f)
                        .texOffs(46, 46).addBox(-5f, -1f, -5f, 3f, 1f, 3f)
                        .texOffs(58, 46).addBox(2f, -1f, -5f, 3f, 1f, 3f),
                PartPose.offset(0f, 24f, 0f));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float t = state.ageInTicks;
        armL.xRot = -0.5f;
        armR.xRot = -0.7f;
        float sw = Anim.strike(state);
        armL.xRot -= sw * 1.4f;
        armR.xRot -= sw * 1.4f;
        this.root().y = Mth.sin(t * 0.1f) * 1.0f;
    }
}
