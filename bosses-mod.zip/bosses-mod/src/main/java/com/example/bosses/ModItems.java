package com.example.bosses;

import java.util.function.Function;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.block.Block;

/** Materiales especiales de los jefes y las herramientas hechas con ellos. */
public final class ModItems {
    private ModItems() {}

    private static TagKey<Block> blockTag(String name) {
        return TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, name));
    }

    private static TagKey<Item> itemTag(String name) {
        return TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, name));
    }

    public static final ToolMaterial SAP = new ToolMaterial(blockTag("incorrect_for_sap_tool"), 480, 6.5f, 2.0f, 16, itemTag("repairs_sap_tools"));
    public static final ToolMaterial CORAL = new ToolMaterial(blockTag("incorrect_for_coral_tool"), 900, 7.5f, 2.5f, 14, itemTag("repairs_coral_tools"));
    public static final ToolMaterial SPECTRAL = new ToolMaterial(blockTag("incorrect_for_spectral_tool"), 1300, 8.5f, 3.0f, 20, itemTag("repairs_spectral_tools"));
    public static final ToolMaterial LUNAR = new ToolMaterial(blockTag("incorrect_for_lunar_tool"), 1800, 9.5f, 4.0f, 18, itemTag("repairs_lunar_tools"));

    private static Item register(String id, Function<Item.Properties, Item> factory, boolean tool) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, id));
        Item item = factory.apply(new Item.Properties().setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        if (tool) {
            CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                    .register(output -> output.accept(item));
        } else {
            CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS)
                    .register(output -> output.accept(item));
        }
        return item;
    }

    private static void material(String id) {
        register(id, Item::new, false);
    }

    private static void tool(String id, Function<Item.Properties, Item> factory) {
        register(id, factory, true);
    }

    public static void init() {
        material("sap_heart");
        material("amanita_cap");
        tool("sap_sword", p -> new Item(p.sword(SAP, 3.0f, -2.4f)));
        tool("sap_pickaxe", p -> new Item(p.pickaxe(SAP, 1.0f, -2.8f)));
        tool("sap_axe", p -> new AxeItem(SAP, 5.0f, -3.0f, p));
        tool("sap_shovel", p -> new ShovelItem(SAP, 1.5f, -3.0f, p));
        tool("sap_hoe", p -> new HoeItem(SAP, -3.0f, 0.0f, p));
        material("coral_ingot");
        material("shell_shard");
        tool("coral_sword", p -> new Item(p.sword(CORAL, 3.0f, -2.4f)));
        tool("coral_pickaxe", p -> new Item(p.pickaxe(CORAL, 1.0f, -2.8f)));
        tool("coral_axe", p -> new AxeItem(CORAL, 5.0f, -3.0f, p));
        tool("coral_shovel", p -> new ShovelItem(CORAL, 1.5f, -3.0f, p));
        tool("coral_hoe", p -> new HoeItem(CORAL, -3.0f, 0.0f, p));
        material("spectral_essence");
        material("tattered_hood");
        tool("spectral_sword", p -> new Item(p.sword(SPECTRAL, 3.0f, -2.4f)));
        tool("spectral_pickaxe", p -> new Item(p.pickaxe(SPECTRAL, 1.0f, -2.8f)));
        tool("spectral_axe", p -> new AxeItem(SPECTRAL, 5.0f, -3.0f, p));
        tool("spectral_shovel", p -> new ShovelItem(SPECTRAL, 1.5f, -3.0f, p));
        tool("spectral_hoe", p -> new HoeItem(SPECTRAL, -3.0f, 0.0f, p));
        material("lunar_feather");
        material("owl_feather");
        tool("lunar_sword", p -> new Item(p.sword(LUNAR, 3.0f, -2.4f)));
        tool("lunar_pickaxe", p -> new Item(p.pickaxe(LUNAR, 1.0f, -2.8f)));
        tool("lunar_axe", p -> new AxeItem(LUNAR, 5.0f, -3.0f, p));
        tool("lunar_shovel", p -> new ShovelItem(LUNAR, 1.5f, -3.0f, p));
        tool("lunar_hoe", p -> new HoeItem(LUNAR, -3.0f, 0.0f, p));
    }
}
