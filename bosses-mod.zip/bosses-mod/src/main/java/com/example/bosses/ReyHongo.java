package com.example.bosses;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class ReyHongo extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            getDisplayName(), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.PROGRESS);
    private int sporeCooldown = 100;
    private int slamCooldown = 160;

    public ReyHongo(EntityType<? extends ReyHongo> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0)
                .add(Attributes.MOVEMENT_SPEED, 0.23)
                .add(Attributes.ATTACK_DAMAGE, 12.0)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.7)
                .add(Attributes.ARMOR, 6.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 16.0f));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level() instanceof ServerLevel serverLevel) {
            bossEvent.setProgress(getHealth() / getMaxHealth());
            abilities(serverLevel);
        }
    }

    private void abilities(ServerLevel level) {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double dist = distanceToSqr(target);

        // Nube de esporas: envenena a los jugadores cercanos
        if (--sporeCooldown <= 0 && dist < 14 * 14) {
            sporeCooldown = 140;
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(8.0))) {
                p.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
            }
            level.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR,
                    getX(), getY() + 2.0, getZ(), 80, 3.0, 1.5, 3.0, 0.02);
        }

        // Golpe de tallo: empuja y ralentiza a todo lo cercano
        if (--slamCooldown <= 0 && dist < 7 * 7) {
            slamCooldown = 220;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class,
                    getBoundingBox().inflate(6.0), x -> x != this && !(x instanceof ReyHongo))) {
                e.knockback(1.2, getX() - e.getX(), getZ() - e.getZ());
                e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
            }
            level.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.5, getZ(), 40, 2.5, 0.2, 2.5, 0.05);
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
