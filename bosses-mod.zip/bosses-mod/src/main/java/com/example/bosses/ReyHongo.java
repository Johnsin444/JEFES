package com.example.bosses;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Rey Hongo: un arbol gigante con raices clavadas al suelo. No se mueve, pero domina el area. */
public class ReyHongo extends BossBase {
    private int sporeCooldown = 100;
    private int slamCooldown = 160;
    private int rootCooldown = 120;
    private int summonCooldown = 400;

    public ReyHongo(EntityType<? extends ReyHongo> type, Level level) {
        super(type, level, "entity.bosses.rey_hongo", BossEvent.BossBarColor.GREEN);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 600.0)
                .add(Attributes.MOVEMENT_SPEED, 0.0)
                .add(Attributes.ATTACK_DAMAGE, 14.0)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.ARMOR, 8.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 24.0f));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void push(double x, double y, double z) {
        // Las raices lo mantienen clavado al suelo
    }

    @Override
    protected void abilities(ServerLevel level) {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double dist = distanceToSqr(target);
        double radius = isPhaseTwo() ? 11.0 : 8.0;

        // Nube de esporas
        if (--sporeCooldown <= 0 && dist < 16 * 16) {
            sporeCooldown = cd(140);
            act("cast");
            schedule(18, lv -> {
            playSound(ModSounds.REY_HONGO_ATTACK, 2.0f, 1.0f);
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(radius))) {
                p.addEffect(new MobEffectInstance(MobEffects.POISON, isPhaseTwo() ? 160 : 100, isPhaseTwo() ? 1 : 0));
            }
            level.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR,
                    getX(), getY() + 3.0, getZ(), 100, radius / 2.0, 2.0, radius / 2.0, 0.02);
            });
        }

        // Raices atrapadoras: inmovilizan y jalan hacia el arbol
        if (--rootCooldown <= 0 && dist < 14 * 14) {
            rootCooldown = cd(180);
            act("rain");
            schedule(16, lv -> {
            playSound(ModSounds.REY_HONGO_ATTACK, 2.0f, 0.6f);
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(14.0))) {
                p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 70, 3));
                if (p.distanceToSqr(this) < 8 * 8) {
                    p.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 0));
                }
                double dx = getX() - p.getX();
                double dz = getZ() - p.getZ();
                double len = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
                p.push(dx / len * 0.9, 0.2, dz / len * 0.9);
                level.sendParticles(ParticleTypes.COMPOSTER, p.getX(), p.getY() + 0.2, p.getZ(), 15, 0.4, 0.1, 0.4, 0.05);
            }
            });
        }

        // Golpe de ramas: empuja y ralentiza a lo que tenga cerca
        if (--slamCooldown <= 0 && dist < 8 * 8) {
            slamCooldown = cd(220);
            act("smash");
            schedule(17, lv -> {
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class,
                    getBoundingBox().inflate(6.0), x -> x != this && !(x instanceof BossBase))) {
                double dx = e.getX() - getX();
                double dz = e.getZ() - getZ();
                double len = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
                e.push(dx / len * 1.4, 0.6, dz / len * 1.4);
                e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
            }
            level.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.5, getZ(), 50, 3.0, 0.2, 3.0, 0.05);
            });
        }

        // Segunda fase: invoca Mini Hongos cada cierto tiempo
        if (isPhaseTwo() && --summonCooldown <= 0) {
            summonCooldown = 500;
            act("summon");
            schedule(26, lv -> summonMinis(level, l -> new GeoMini(BossesMod.mini("hongo_mini"), l), 2, 8));
        }
    }

    @Override
    protected SoundEvent phaseSound() {
        return ModSounds.REY_HONGO_PHASE;
    }

    @Override
    protected void onPhaseTwo(ServerLevel level) {
        summonMinis(level, l -> new GeoMini(BossesMod.mini("hongo_mini"), l), 3, 8);
    }

    @Override
    protected void applyPhaseTwoStats() {
        setBase(Attributes.ATTACK_DAMAGE, 14.0 * 1.3);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.REY_HONGO_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.REY_HONGO_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.REY_HONGO_DEATH;
    }
}
