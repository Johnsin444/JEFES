package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class HongoMiniModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "hongo_mini"), "main");

    private final ModelPart legL;
    private final ModelPart legR;
    private final ModelPart sword;

    public HongoMiniModel(ModelPart root) {
        super(root);
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
        this.sword = root.getChild("sword");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-3f, -8f, -3f, 6f, 8f, 6f)
                        .texOffs(30, 16).addBox(-4f, -3f, -4f, 8f, 2f, 8f),
                PartPose.offset(0f, 21f, 0f));
        root.addOrReplaceChild("cap",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-6f, -11f, -6f, 12f, 4f, 12f)
                        .texOffs(0, 30).addBox(-4f, -13f, -4f, 8f, 2f, 8f),
                PartPose.offset(0f, 21f, 0f));
        root.addOrReplaceChild("leg_l",
                CubeListBuilder.create()
                        .texOffs(32, 30).addBox(-1f, 0f, -1f, 2f, 3f, 2f),
                PartPose.offset(2f, 21f, 0f));
        root.addOrReplaceChild("leg_r",
                CubeListBuilder.create()
                        .texOffs(32, 30).addBox(-1f, 0f, -1f, 2f, 3f, 2f),
                PartPose.offset(-2f, 21f, 0f));
        root.addOrReplaceChild("sword",
                CubeListBuilder.create()
                        .texOffs(24, 16).addBox(-1f, -13f, -1f, 2f, 10f, 1f)
                        .texOffs(0, 40).addBox(-2f, -3f, -1f, 4f, 1f, 2f)
                        .texOffs(48, 30).addBox(-1f, -2f, -1f, 2f, 3f, 2f),
                PartPose.offset(-5f, 19f, -3f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        legL.xRot = Mth.cos(p * 0.9f) * 1.2f * sp;
        legR.xRot = -Mth.cos(p * 0.9f) * 1.2f * sp;
        sword.xRot = -0.4f + Mth.sin(t * 0.12f) * 0.1f;
    }
}
