package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class HongoMiniModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "hongo_mini"), "main");

    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public HongoMiniModel(ModelPart root) {
        super(root);
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("stem",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3, -8, -3, 6, 8, 6),
                PartPose.offset(0, 21, 0));
        root.addOrReplaceChild("cap",
                CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-6, -11, -6, 12, 4, 12)
                        .texOffs(0, 34).addBox(-4, -13, -4, 8, 2, 8),
                PartPose.offset(0, 21, 0));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(0, 46).addBox(-1, 0, -1, 2, 3, 2),
                PartPose.offset(2, 21, 0));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 46).addBox(-1, 0, -1, 2, 3, 2),
                PartPose.offset(-2, 21, 0));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float swing = Mth.cos(state.walkAnimationPos * 0.9f) * 1.2f * state.walkAnimationSpeed;
        rightLeg.xRot = swing;
        leftLeg.xRot = -swing;
    }
}
