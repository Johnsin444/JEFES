package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class CangrejitoModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "cangrejito"), "main");

    private final ModelPart clawL;
    private final ModelPart clawR;
    private final ModelPart legL0;
    private final ModelPart legL1;
    private final ModelPart legR0;
    private final ModelPart legR1;

    public CangrejitoModel(ModelPart root) {
        super(root);
        this.clawL = root.getChild("claw_l");
        this.clawR = root.getChild("claw_r");
        this.legL0 = root.getChild("leg_l0");
        this.legL1 = root.getChild("leg_l1");
        this.legR0 = root.getChild("leg_r0");
        this.legR1 = root.getChild("leg_r1");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-5f, -7f, -4f, 10f, 4f, 8f)
                        .texOffs(20, 12).addBox(-4f, -9f, -3f, 8f, 2f, 6f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("eye_l",
                CubeListBuilder.create()
                        .texOffs(36, 22).addBox(-1f, -3f, -1f, 2f, 3f, 2f)
                        .texOffs(44, 30).addBox(-1f, -5f, -1f, 2f, 2f, 2f),
                PartPose.offset(2f, 15f, -4f));
        root.addOrReplaceChild("claw_l",
                CubeListBuilder.create()
                        .texOffs(36, 0).addBox(-2f, -2f, -6f, 4f, 4f, 6f)
                        .texOffs(0, 22).addBox(-3f, -3f, -9f, 6f, 5f, 3f),
                PartPose.offset(6f, 19f, -3f));
        root.addOrReplaceChild("leg_l0",
                CubeListBuilder.create()
                        .texOffs(44, 22).addBox(0f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(5f, 21f, -2f));
        root.addOrReplaceChild("leg_l1",
                CubeListBuilder.create()
                        .texOffs(44, 22).addBox(0f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(5f, 21f, 2f));
        root.addOrReplaceChild("eye_r",
                CubeListBuilder.create()
                        .texOffs(36, 22).addBox(-1f, -3f, -1f, 2f, 3f, 2f)
                        .texOffs(44, 30).addBox(-1f, -5f, -1f, 2f, 2f, 2f),
                PartPose.offset(-2f, 15f, -4f));
        root.addOrReplaceChild("claw_r",
                CubeListBuilder.create()
                        .texOffs(36, 0).addBox(-2f, -2f, -6f, 4f, 4f, 6f)
                        .texOffs(0, 22).addBox(-3f, -3f, -9f, 6f, 5f, 3f),
                PartPose.offset(-6f, 19f, -3f));
        root.addOrReplaceChild("leg_r0",
                CubeListBuilder.create()
                        .texOffs(20, 30).addBox(-4f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(-5f, 21f, -2f));
        root.addOrReplaceChild("leg_r1",
                CubeListBuilder.create()
                        .texOffs(20, 30).addBox(-4f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(-5f, 21f, 2f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        clawL.xRot = Mth.sin(t * 0.3f) * 0.25f;
        clawR.xRot = -Mth.sin(t * 0.3f) * 0.25f;
        legL0.zRot = 0.1f + Mth.cos(p * 1.1f) * 0.4f * sp;
        legL1.zRot = 0.1f + Mth.cos(p * 1.1f + 3.14f) * 0.4f * sp;
        legR0.zRot = -(0.1f + Mth.cos(p * 1.1f + 3.14f) * 0.4f * sp);
        legR1.zRot = -(0.1f + Mth.cos(p * 1.1f) * 0.4f * sp);
    }
}
