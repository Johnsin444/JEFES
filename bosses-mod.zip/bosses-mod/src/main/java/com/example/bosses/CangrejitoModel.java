package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class CangrejitoModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "cangrejito"), "main");

    private final ModelPart clawR;
    private final ModelPart sword;
    private final ModelPart legL0;
    private final ModelPart legL1;
    private final ModelPart legR0;
    private final ModelPart legR1;

    public CangrejitoModel(ModelPart root) {
        super(root);
        this.clawR = root.getChild("claw_r");
        this.sword = root.getChild("sword");
        this.legL0 = root.getChild("leg_l0");
        this.legL1 = root.getChild("leg_l1");
        this.legR0 = root.getChild("leg_r0");
        this.legR1 = root.getChild("leg_r1");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-6f, -9f, -5f, 12f, 5f, 10f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("eye_l",
                CubeListBuilder.create()
                        .texOffs(0, 33).addBox(-1f, -3f, -1f, 2f, 3f, 2f)
                        .texOffs(18, 25).addBox(-2f, -6f, -2f, 4f, 3f, 4f),
                PartPose.offset(2f, 15f, -4f));
        root.addOrReplaceChild("leg_l0",
                CubeListBuilder.create()
                        .texOffs(8, 33).addBox(0f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(5f, 21f, -2f));
        root.addOrReplaceChild("leg_l1",
                CubeListBuilder.create()
                        .texOffs(8, 33).addBox(0f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(5f, 21f, 2f));
        root.addOrReplaceChild("eye_r",
                CubeListBuilder.create()
                        .texOffs(0, 33).addBox(-1f, -3f, -1f, 2f, 3f, 2f)
                        .texOffs(18, 25).addBox(-2f, -6f, -2f, 4f, 3f, 4f),
                PartPose.offset(-2f, 15f, -4f));
        root.addOrReplaceChild("leg_r0",
                CubeListBuilder.create()
                        .texOffs(40, 33).addBox(-4f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(-5f, 21f, -2f));
        root.addOrReplaceChild("leg_r1",
                CubeListBuilder.create()
                        .texOffs(40, 33).addBox(-4f, 0f, -1f, 4f, 3f, 2f),
                PartPose.offset(-5f, 21f, 2f));
        root.addOrReplaceChild("claw_l",
                CubeListBuilder.create()
                        .texOffs(0, 15).addBox(-2f, -2f, -6f, 4f, 4f, 6f)
                        .texOffs(40, 15).addBox(-3f, -3f, -9f, 6f, 5f, 3f),
                PartPose.offset(7f, 19f, -3f));
        root.addOrReplaceChild("claw_r",
                CubeListBuilder.create()
                        .texOffs(0, 15).addBox(-2f, -2f, -6f, 4f, 4f, 6f)
                        .texOffs(40, 15).addBox(-3f, -3f, -9f, 6f, 5f, 3f),
                PartPose.offset(-7f, 19f, -3f));
        root.addOrReplaceChild("sword",
                CubeListBuilder.create()
                        .texOffs(44, 0).addBox(-1f, -18f, -1f, 2f, 14f, 1f)
                        .texOffs(0, 38).addBox(-3f, -5f, -1f, 6f, 1f, 2f)
                        .texOffs(50, 25).addBox(-1f, -4f, -1f, 2f, 4f, 2f),
                PartPose.offset(7f, 19f, -9f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float p = state.walkAnimationPos;
        float sp = Math.min(1.0f, state.walkAnimationSpeed * 2.0f);
        float t = state.ageInTicks;
        clawR.xRot = Mth.sin(t * 0.3f) * 0.25f;
        sword.zRot = -(0.1f + Mth.sin(t * 0.2f) * 0.1f);
        legL0.zRot = 0.1f + Mth.cos(p * 1.1f) * 0.4f * sp;
        legL1.zRot = 0.1f + Mth.cos(p * 1.1f + 3.14f) * 0.4f * sp;
        legR0.zRot = -(0.1f + Mth.cos(p * 1.1f + 3.14f) * 0.4f * sp);
        legR1.zRot = -(0.1f + Mth.cos(p * 1.1f) * 0.4f * sp);
    }
}
