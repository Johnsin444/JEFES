package com.example.bosses;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class BuhoEclipse extends FlyingBossBase {
    private int diveCooldown = 100;
    private int featherCooldown = 140;
    private int eclipseCooldown = 300;
    private int summonCooldown = 450;
    private int beamCooldown = 120;
    private int rainCooldown = 240;
    private int gustCooldown = 180;

    public BuhoEclipse(EntityType<? extends BuhoEclipse> type, Level level) {
        super(type, level, "entity.bosses.buho_eclipse", BossEvent.BossBarColor.PURPLE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 500.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FLYING_SPEED, 0.7)
                .add(Attributes.ATTACK_DAMAGE, 11.0)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.ARMOR, 8.0);
    }

    @Override
    protected void abilities(ServerLevel level) {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double dist = distanceToSqr(target);

        if (isPhaseTwo() && --summonCooldown <= 0) {
            summonCooldown = 500;
            act("summon");
            schedule(26, lv -> summonMinis(level, l -> new GeoMini(BossesMod.mini("polluelo"), l), 2, 9));
        }

        // Picado
        if (--diveCooldown <= 0 && dist > 7 * 7 && dist < 30 * 30) {
            diveCooldown = cd(120);
            act("attack");
            Vec3 dir = target.position().add(0, 1.0, 0).subtract(position()).normalize();
            schedule(8, lv -> setDeltaMovement(dir.x * 1.1, dir.y * 1.1, dir.z * 1.1));
        }

        // Plumas cortantes: dano instantaneo a quien vea
        if (--featherCooldown <= 0 && dist < 14 * 14) {
            featherCooldown = cd(160);
            act("gust");
            schedule(11, lv -> {
                playSound(ModSounds.BUHO_ECLIPSE_ATTACK, 2.0f, 1.0f);
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(14.0))) {
                    if (hasLineOfSight(p)) {
                        p.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 0));
                        level.sendParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1.0, p.getZ(), 20, 0.4, 0.6, 0.4, 0.2);
                    }
                }
            });
        }

        // Eclipse: oscurece la zona
        if (--eclipseCooldown <= 0) {
            eclipseCooldown = cd(400);
            act("summon");
            schedule(18, lv -> {
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(24.0))) {
                    p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0));
                }
                level.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + 1.5, getZ(), 60, 3.0, 1.5, 3.0, 0.05);
            });
        }

        // Rayo lunar: apunta, avisa con una linea de luz y dispara
        if (--beamCooldown <= 0 && dist > 5 * 5 && dist < 30 * 30 && hasLineOfSight(target)) {
            beamCooldown = cd(170);
            act("cast");
            playSound(ModSounds.BUHO_ECLIPSE_ATTACK, 2.0f, 0.7f);
            Vec3 aimPos = target.getEyePosition();
            for (int t = 8; t <= 24; t += 8) {
                schedule(t, lv -> beam(level, aimPos, false));
            }
            schedule(30, lv -> beam(level, aimPos, true));
        }

        // Lluvia lunar: columnas de luz que caen alrededor del objetivo
        if (--rainCooldown <= 0 && dist < 32 * 32) {
            rainCooldown = cd(300);
            act("rain");
            int n = isPhaseTwo() ? 9 : 6;
            for (int i = 0; i < n; i++) {
                double ox = i == 0 ? 0.0 : (random.nextDouble() - 0.5) * 14.0;
                double oz = i == 0 ? 0.0 : (random.nextDouble() - 0.5) * 14.0;
                moonStrike(level, target.getX() + ox, target.getY(), target.getZ() + oz, 24 + i * 5);
            }
        }

        // Rafaga de alas: empuja y levanta a los jugadores cercanos
        if (--gustCooldown <= 0 && dist < 9 * 9) {
            gustCooldown = cd(200);
            act("gust");
            schedule(11, lv -> {
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(9.0))) {
                    double dx = p.getX() - getX();
                    double dz = p.getZ() - getZ();
                    double len = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
                    p.push(dx / len * 1.3, 0.5, dz / len * 1.3);
                    p.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 30, 1));
                }
                level.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.0, getZ(), 80, 3.0, 0.8, 3.0, 0.2);
            });
        }
    }

    private void beam(ServerLevel level, Vec3 aimPos, boolean damage) {
        Vec3 from = getEyePosition().add(0.0, -0.4, 0.0);
        Vec3 dir = aimPos.subtract(from).normalize();
        java.util.HashSet<Player> hit = new java.util.HashSet<>();
        for (double d = 1.0; d < 34.0; d += 0.6) {
            Vec3 pt = from.add(dir.scale(d));
            if (!level.getBlockState(BlockPos.containing(pt)).isAir()) break;
            level.sendParticles(ParticleTypes.END_ROD, pt.x, pt.y, pt.z, damage ? 3 : 1, 0.05, 0.05, 0.05, 0.0);
            if (!damage) continue;
            for (Player p : level.getEntitiesOfClass(Player.class, new AABB(pt, pt).inflate(1.2))) {
                if (hit.add(p)) {
                    p.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, isPhaseTwo() ? 1 : 0));
                    p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 1));
                }
            }
        }
    }

    private void moonStrike(ServerLevel level, double x, double y, double z, int start) {
        for (int t = 0; t <= 10; t += 10) {
            schedule(start + t, lv -> {
                for (int a = 0; a < 360; a += 24) {
                    double r = Math.toRadians(a);
                    level.sendParticles(ParticleTypes.END_ROD, x + Math.cos(r) * 2.6, y + 0.1, z + Math.sin(r) * 2.6,
                            1, 0.0, 0.0, 0.0, 0.0);
                }
            });
        }
        schedule(start + 22, lv -> {
            for (Player p : level.getEntitiesOfClass(Player.class, new AABB(x - 2.6, y - 4.0, z - 2.6, x + 2.6, y + 4.0, z + 2.6))) {
                double dx = p.getX() - x;
                double dz = p.getZ() - z;
                if (dx * dx + dz * dz <= 2.6 * 2.6) {
                    p.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 0));
                    p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 30, 1));
                }
            }
            level.sendParticles(ParticleTypes.END_ROD, x, y + 3.0, z, 50, 0.3, 3.0, 0.3, 0.02);
            level.sendParticles(ParticleTypes.CLOUD, x, y + 0.3, z, 20, 1.2, 0.2, 1.2, 0.05);
        });
    }

    @Override
    protected SoundEvent phaseSound() {
        return ModSounds.BUHO_ECLIPSE_PHASE;
    }

    @Override
    protected void onPhaseTwo(ServerLevel level) {
        summonMinis(level, l -> new GeoMini(BossesMod.mini("polluelo"), l), 4, 9);
    }

    @Override
    protected void applyPhaseTwoStats() {
        setBase(Attributes.ATTACK_DAMAGE, 11.0 * 1.3);
        setBase(Attributes.FLYING_SPEED, 0.7 * 1.3);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.BUHO_ECLIPSE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.BUHO_ECLIPSE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.BUHO_ECLIPSE_DEATH;
    }
}
