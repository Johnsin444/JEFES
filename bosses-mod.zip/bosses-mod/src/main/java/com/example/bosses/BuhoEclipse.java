package com.example.bosses;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class BuhoEclipse extends FlyingBossBase {
    private int diveCooldown = 100;
    private int featherCooldown = 140;
    private int eclipseCooldown = 300;

    public BuhoEclipse(EntityType<? extends BuhoEclipse> type, Level level) {
        super(type, level, "entity.bosses.buho_eclipse", BossEvent.BossBarColor.PURPLE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 350.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FLYING_SPEED, 0.7)
                .add(Attributes.ATTACK_DAMAGE, 11.0)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.ARMOR, 4.0);
    }

    @Override
    protected void abilities(ServerLevel level) {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double dist = distanceToSqr(target);

        // Picado
        if (--diveCooldown <= 0 && dist > 7 * 7 && dist < 30 * 30) {
            diveCooldown = 120;
            Vec3 dir = target.position().add(0, 1.0, 0).subtract(position()).normalize();
            setDeltaMovement(dir.x * 1.1, dir.y * 1.1, dir.z * 1.1);
        }

        // Plumas cortantes: dano instantaneo a quien vea
        if (--featherCooldown <= 0 && dist < 14 * 14) {
            featherCooldown = 160;
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(14.0))) {
                if (hasLineOfSight(p)) {
                    p.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 0));
                    level.sendParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1.0, p.getZ(), 20, 0.4, 0.6, 0.4, 0.2);
                }
            }
        }

        // Eclipse: oscurece la zona
        if (--eclipseCooldown <= 0) {
            eclipseCooldown = 400;
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(24.0))) {
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0));
            }
            level.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + 1.5, getZ(), 60, 3.0, 1.5, 3.0, 0.05);
        }
    }
}
