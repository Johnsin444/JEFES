package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class HongoModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "rey_hongo"), "main");

    private final ModelPart leftArm;
    private final ModelPart rightArm;

    public HongoModel(ModelPart root) {
        super(root);
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("stem",
                CubeListBuilder.create().texOffs(0, 0).addBox(-6, -18, -6, 12, 18, 12),
                PartPose.offset(0, 24, 0));

        root.addOrReplaceChild("cap",
                CubeListBuilder.create()
                        .texOffs(0, 32).addBox(-14, -25, -14, 28, 7, 28)
                        .texOffs(0, 70).addBox(-10, -31, -10, 20, 6, 20)
                        .texOffs(0, 98).addBox(-6, -34, -6, 12, 3, 12)
                        .texOffs(50, 0).addBox(-6, -37, -6, 12, 3, 12)
                        .texOffs(50, 16).addBox(-6, -42, -6, 3, 5, 3)
                        .texOffs(50, 16).addBox(3, -42, -6, 3, 5, 3)
                        .texOffs(50, 16).addBox(-6, -42, 3, 3, 5, 3)
                        .texOffs(50, 16).addBox(3, -42, 3, 3, 5, 3)
                        .texOffs(50, 28).addBox(-1.5f, -44, -1.5f, 3, 7, 3),
                PartPose.offset(0, 24, 0));

        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create()
                        .texOffs(100, 0).addBox(-2, 0, -2, 4, 12, 4)
                        .texOffs(100, 20).addBox(-3, 12, -3, 6, 5, 6),
                PartPose.offset(9, 7, 0));
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create()
                        .texOffs(100, 0).addBox(-2, 0, -2, 4, 12, 4)
                        .texOffs(100, 20).addBox(-3, 12, -3, 6, 5, 6),
                PartPose.offset(-9, 7, 0));

        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float swing = Mth.cos(state.walkAnimationPos * 0.6662f) * state.walkAnimationSpeed;
        rightArm.xRot = swing;
        leftArm.xRot = -swing;
        float sway = 0.12f + Mth.cos(state.ageInTicks * 0.09f) * 0.05f;
        leftArm.zRot = -sway;
        rightArm.zRot = sway;
    }
}
