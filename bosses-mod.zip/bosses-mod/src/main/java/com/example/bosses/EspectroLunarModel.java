package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class EspectroLunarModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "espectro_lunar"), "main");

    private final ModelPart arm;

    public EspectroLunarModel(ModelPart root) {
        super(root);
        this.arm = root.getChild("arm");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("robe",
                CubeListBuilder.create()
                        .texOffs(8, 0).addBox(-6f, -20f, -4f, 12f, 18f, 8f)
                        .texOffs(92, 40).addBox(-6f, -2f, -4f, 3f, 2f, 8f)
                        .texOffs(48, 40).addBox(-3f, -3f, -4f, 3f, 3f, 8f)
                        .texOffs(0, 52).addBox(0f, -2f, -4f, 3f, 2f, 8f)
                        .texOffs(70, 40).addBox(3f, -3f, -4f, 3f, 3f, 8f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("medal",
                CubeListBuilder.create()
                        .texOffs(78, 52).addBox(-2f, -18f, -5f, 4f, 4f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("pads",
                CubeListBuilder.create()
                        .texOffs(0, 40).addBox(-9f, -21f, -4f, 4f, 4f, 8f)
                        .texOffs(24, 40).addBox(5f, -21f, -4f, 4f, 4f, 8f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("hood",
                CubeListBuilder.create()
                        .texOffs(48, 0).addBox(-7f, -30f, -5f, 14f, 10f, 10f)
                        .texOffs(32, 52).addBox(-4f, -33f, -3f, 8f, 3f, 6f)
                        .texOffs(60, 52).addBox(-4f, -28f, -6f, 8f, 5f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("arm",
                CubeListBuilder.create()
                        .texOffs(96, 0).addBox(-2f, 0f, -2f, 4f, 10f, 4f),
                PartPose.offset(-8f, -2f, 0f));
        root.addOrReplaceChild("staff",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1f, -30f, -1f, 2f, 38f, 2f)
                        .texOffs(22, 52).addBox(-5f, -36f, -1f, 3f, 8f, 2f)
                        .texOffs(88, 52).addBox(-3f, -38f, -1f, 7f, 3f, 2f)
                        .texOffs(106, 52).addBox(-3f, -30f, -1f, 3f, 2f, 2f),
                PartPose.offset(-8f, 6f, -6f));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        this.root().y = Mth.sin(state.ageInTicks * 0.12f) * 1.5f;
        arm.xRot = -0.7f;
        float sw = Anim.strike(state);
        arm.xRot -= sw * 1.6f;
        this.root().xRot = Anim.walk(state) * 0.1f + sw * 0.12f;
        this.root().zRot = Mth.sin(state.ageInTicks * 0.07f) * 0.05f;
    }
}
