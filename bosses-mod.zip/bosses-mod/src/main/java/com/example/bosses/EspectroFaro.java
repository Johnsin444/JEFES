package com.example.bosses;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class EspectroFaro extends FlyingBossBase {
    private int blindCooldown = 100;
    private int blinkCooldown = 160;
    private int fogCooldown = 200;
    private int summonCooldown = 450;
    private int boltCooldown = 110;
    private int curseCooldown = 220;

    public EspectroFaro(EntityType<? extends EspectroFaro> type, Level level) {
        super(type, level, "entity.bosses.espectro_faro", BossEvent.BossBarColor.BLUE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 450.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FLYING_SPEED, 0.6)
                .add(Attributes.ATTACK_DAMAGE, 9.0)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5)
                .add(Attributes.ARMOR, 6.0);
    }

    @Override
    protected void abilities(ServerLevel level) {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double dist = distanceToSqr(target);

        if (isPhaseTwo() && --summonCooldown <= 0) {
            summonCooldown = 500;
            act("summon");
            schedule(26, lv -> summonMinis(level, l -> new GeoMini(BossesMod.mini("fantasmita"), l), 2, 9));
        }

        // Linterna que ciega
        if (--blindCooldown <= 0 && dist < 12 * 12) {
            blindCooldown = cd(160);
            act("summon");
            schedule(18, lv -> {
                playSound(ModSounds.ESPECTRO_FARO_ATTACK, 2.0f, 1.0f);
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(12.0))) {
                    p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                }
                level.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.5, getZ(), 40, 1.5, 1.0, 1.5, 0.05);
            });
        }

        // Almas errantes: abanico de proyectiles magicos
        if (--boltCooldown <= 0 && dist > 4 * 4 && dist < 28 * 28 && hasLineOfSight(target)) {
            boltCooldown = cd(150);
            act("cast");
            playSound(ModSounds.ESPECTRO_FARO_ATTACK, 2.0f, 1.4f);
            schedule(16, lv -> fireBolts(level, target));
        }

        // Circulo de maldicion: marca el suelo y estalla segundos despues
        if (--curseCooldown <= 0 && dist < 30 * 30) {
            curseCooldown = cd(280);
            act("rain");
            int circles = isPhaseTwo() ? 3 : 1;
            for (int i = 0; i < circles; i++) {
                double ox = i == 0 ? 0.0 : (random.nextDouble() - 0.5) * 9.0;
                double oz = i == 0 ? 0.0 : (random.nextDouble() - 0.5) * 9.0;
                curse(level, target.getX() + ox, target.getY(), target.getZ() + oz, 26 + i * 6);
            }
        }

        // Paso fantasma: aparece cerca del objetivo si hay espacio libre
        if (--blinkCooldown <= 0 && dist > 5 * 5) {
            blinkCooldown = cd(220);
            double ang = random.nextDouble() * Math.PI * 2.0;
            Vec3 np = target.position().add(Math.cos(ang) * 3.0, 0.5, Math.sin(ang) * 3.0);
            AABB moved = getBoundingBox().move(np.subtract(position()));
            if (level.noCollision(moved)) {
                level.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1.0, getZ(), 30, 0.5, 1.0, 0.5, 0.05);
                setPos(np.x, np.y, np.z);
                level.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1.0, getZ(), 30, 0.5, 1.0, 0.5, 0.05);
            }
        }

        // Niebla fria: ralentiza y debilita
        if (--fogCooldown <= 0 && dist < 10 * 10) {
            fogCooldown = cd(260);
            act("summon");
            schedule(18, lv -> {
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(10.0))) {
                    p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 1));
                    p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                }
                level.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.0, getZ(), 100, 4.0, 1.0, 4.0, 0.02);
            });
        }
    }

    private void fireBolts(ServerLevel level, LivingEntity target) {
        if (!target.isAlive()) return;
        Vec3 from = getEyePosition();
        Vec3 aim = target.getEyePosition().subtract(from).normalize();
        int bolts = isPhaseTwo() ? 7 : 5;
        for (int k = 0; k < bolts; k++) {
            double ang = (k - (bolts - 1) / 2.0) * 0.16;
            Vec3 dir = new Vec3(aim.x * Math.cos(ang) - aim.z * Math.sin(ang), aim.y,
                    aim.x * Math.sin(ang) + aim.z * Math.cos(ang));
            boolean hit = false;
            for (double d = 1.0; d < 26.0 && !hit; d += 0.6) {
                Vec3 pt = from.add(dir.scale(d));
                if (!level.getBlockState(BlockPos.containing(pt)).isAir()) break;
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
                for (Player p : level.getEntitiesOfClass(Player.class, new AABB(pt, pt).inflate(0.9))) {
                    p.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 0));
                    p.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
                    hit = true;
                }
            }
        }
    }

    private void curse(ServerLevel level, double x, double y, double z, int start) {
        for (int t = 0; t < 36; t += 4) {
            schedule(start + t, lv -> {
                for (int a = 0; a < 360; a += 20) {
                    double r = Math.toRadians(a);
                    level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x + Math.cos(r) * 3.5, y + 0.1, z + Math.sin(r) * 3.5,
                            1, 0.0, 0.0, 0.0, 0.0);
                }
            });
        }
        schedule(start + 40, lv -> {
            for (Player p : level.getEntitiesOfClass(Player.class, new AABB(x - 3.5, y - 3.0, z - 3.5, x + 3.5, y + 3.0, z + 3.5))) {
                double dx = p.getX() - x;
                double dz = p.getZ() - z;
                if (dx * dx + dz * dz <= 3.5 * 3.5) {
                    p.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, isPhaseTwo() ? 1 : 0));
                    p.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
                    p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 1));
                }
            }
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y + 0.5, z, 80, 1.6, 0.8, 1.6, 0.15);
            level.sendParticles(ParticleTypes.SOUL, x, y + 1.0, z, 40, 1.2, 1.2, 1.2, 0.05);
        });
    }

    @Override
    protected SoundEvent phaseSound() {
        return ModSounds.ESPECTRO_FARO_PHASE;
    }

    @Override
    protected void onPhaseTwo(ServerLevel level) {
        summonMinis(level, l -> new GeoMini(BossesMod.mini("fantasmita"), l), 4, 9);
    }

    @Override
    protected void applyPhaseTwoStats() {
        setBase(Attributes.ATTACK_DAMAGE, 9.0 * 1.3);
        setBase(Attributes.FLYING_SPEED, 0.6 * 1.3);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.ESPECTRO_FARO_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.ESPECTRO_FARO_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.ESPECTRO_FARO_DEATH;
    }
}
