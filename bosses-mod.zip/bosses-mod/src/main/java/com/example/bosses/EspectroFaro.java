package com.example.bosses;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class EspectroFaro extends FlyingBossBase {
    private int blindCooldown = 100;
    private int blinkCooldown = 160;
    private int fogCooldown = 200;

    public EspectroFaro(EntityType<? extends EspectroFaro> type, Level level) {
        super(type, level, "entity.bosses.espectro_faro", BossEvent.BossBarColor.BLUE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 250.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FLYING_SPEED, 0.6)
                .add(Attributes.ATTACK_DAMAGE, 9.0)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5);
    }

    @Override
    protected void abilities(ServerLevel level) {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double dist = distanceToSqr(target);

        // Linterna que ciega
        if (--blindCooldown <= 0 && dist < 12 * 12) {
            blindCooldown = 160;
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(12.0))) {
                p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
            }
            level.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.5, getZ(), 40, 1.5, 1.0, 1.5, 0.05);
        }

        // Paso fantasma: aparece cerca del objetivo si hay espacio libre
        if (--blinkCooldown <= 0 && dist > 5 * 5) {
            blinkCooldown = 220;
            double ang = random.nextDouble() * Math.PI * 2.0;
            Vec3 np = target.position().add(Math.cos(ang) * 3.0, 0.5, Math.sin(ang) * 3.0);
            AABB moved = getBoundingBox().move(np.subtract(position()));
            if (level.noCollision(moved)) {
                level.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1.0, getZ(), 30, 0.5, 1.0, 0.5, 0.05);
                setPos(np.x, np.y, np.z);
                level.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1.0, getZ(), 30, 0.5, 1.0, 0.5, 0.05);
            }
        }

        // Niebla fria: ralentiza y debilita
        if (--fogCooldown <= 0 && dist < 10 * 10) {
            fogCooldown = 260;
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(10.0))) {
                p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 1));
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
            }
            level.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.0, getZ(), 100, 4.0, 1.0, 4.0, 0.02);
        }
    }
}
