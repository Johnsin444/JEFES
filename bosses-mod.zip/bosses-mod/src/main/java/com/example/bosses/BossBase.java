package com.example.bosses;

import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/** Base comun: barra de jefe arriba + barra de vida sobre la cabeza. */
public abstract class BossBase extends Monster {
    private final String nameKey;
    private final ServerBossEvent bossEvent;
    private int lastHealthShown = -1;

    protected BossBase(EntityType<? extends BossBase> type, Level level, String nameKey,
                       BossEvent.BossBarColor color) {
        super(type, level);
        this.nameKey = nameKey;
        this.bossEvent = new ServerBossEvent(UUID.randomUUID(), Component.translatable(nameKey),
                color, BossEvent.BossBarOverlay.PROGRESS);
        setCustomNameVisible(true);
    }

    protected abstract void abilities(ServerLevel level);

    @Override
    public void aiStep() {
        super.aiStep();
        if (level() instanceof ServerLevel serverLevel) {
            bossEvent.setProgress(getHealth() / getMaxHealth());
            updateNameBar();
            abilities(serverLevel);
        }
    }

    private void updateNameBar() {
        int hp = (int) Math.ceil(getHealth());
        if (hp == lastHealthShown) return;
        lastHealthShown = hp;
        int total = 10;
        int filled = Math.max(0, Math.min(total, Math.round(getHealth() / getMaxHealth() * total)));
        MutableComponent bar = Component.literal("\u2588".repeat(filled)).withStyle(ChatFormatting.RED)
                .append(Component.literal("\u2588".repeat(total - filled)).withStyle(ChatFormatting.DARK_GRAY));
        setCustomName(Component.translatable(nameKey)
                .append(Component.literal(" "))
                .append(bar)
                .append(Component.literal(" " + hp + "/" + (int) getMaxHealth()).withStyle(ChatFormatting.WHITE)));
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
