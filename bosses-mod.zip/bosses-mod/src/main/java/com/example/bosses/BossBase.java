package com.example.bosses;

import java.util.UUID;
import java.util.function.Function;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import com.geckolib.animatable.GeoEntity;
import com.geckolib.animatable.instance.AnimatableInstanceCache;
import com.geckolib.animatable.manager.AnimatableManager;
import com.geckolib.animation.AnimationController;
import com.geckolib.animation.object.PlayState;
import com.geckolib.animation.state.AnimationTest;
import com.geckolib.animation.RawAnimation;
import com.geckolib.util.GeckoLibUtil;

/** Base comun: barras de vida, segunda fase al 50% y ayudantes. */
public abstract class BossBase extends Monster implements GeoEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("walk");
    private static final RawAnimation ATTACK = RawAnimation.begin().thenPlay("attack");
    private static final RawAnimation PHASE = RawAnimation.begin().thenPlay("phase");

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    private final String nameKey;
    private final ServerBossEvent bossEvent;
    private int lastHealthShown = -1;
    private boolean phaseTwo = false;

    protected BossBase(EntityType<? extends BossBase> type, Level level, String nameKey,
                       BossEvent.BossBarColor color) {
        super(type, level);
        this.nameKey = nameKey;
        this.bossEvent = new ServerBossEvent(UUID.randomUUID(), Component.translatable(nameKey),
                color, BossEvent.BossBarOverlay.PROGRESS);
        setCustomNameVisible(true);
    }

    protected abstract void abilities(ServerLevel level);

    protected abstract SoundEvent phaseSound();

    /** Efectos propios al entrar en segunda fase (por ejemplo, invocar mini enemigos). */
    protected abstract void onPhaseTwo(ServerLevel level);

    /** Sube las estadisticas de la segunda fase (se aplican con valores fijos, nunca se acumulan). */
    protected abstract void applyPhaseTwoStats();

    public boolean isPhaseTwo() {
        return phaseTwo;
    }

    /** Tiempo de espera de una habilidad: 40% mas corto en segunda fase. */
    protected int cd(int base) {
        return phaseTwo ? (int) (base * 0.6) : base;
    }

    protected void setBase(net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attribute,
                           double value) {
        AttributeInstance instance = getAttribute(attribute);
        if (instance != null) instance.setBaseValue(value);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level() instanceof ServerLevel serverLevel) {
            bossEvent.setProgress(getHealth() / getMaxHealth());
            updateNameBar();
            if (!phaseTwo && getHealth() > 0 && getHealth() <= getMaxHealth() * 0.5f) {
                phaseTwo = true;
                enterPhaseTwo(serverLevel);
            }
            abilities(serverLevel);
        }
    }

    private void enterPhaseTwo(ServerLevel level) {
        bossEvent.setColor(BossEvent.BossBarColor.RED);
        applyPhaseTwoStats();
        triggerAnim("action", "phase");
        playSound(phaseSound(), 4.0f, 1.0f);
        level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.0, getZ(), 6, 1.5, 1.0, 1.5, 0.0);
        MutableComponent msg = Component.literal("\u00a7c\u00a1")
                .append(Component.translatable(nameKey))
                .append(Component.literal(" entra en su segunda fase!"));
        for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(48.0))) {
            p.sendSystemMessage(msg, true);
        }
        onPhaseTwo(level);
    }

    /** Invoca mini enemigos alrededor del jefe, sin pasar de un maximo cercano. */
    protected void summonMinis(ServerLevel level, Function<Level, Mob> factory, int count, int cap) {
        int near = level.getEntitiesOfClass(Monster.class, getBoundingBox().inflate(20.0),
                e -> e != this && !(e instanceof BossBase)).size();
        for (int i = 0; i < count && near + i < cap; i++) {
            Mob mini = factory.apply(level);
            double ang = random.nextDouble() * Math.PI * 2.0;
            double r = 2.5 + random.nextDouble() * 2.0;
            mini.setPos(getX() + Math.cos(ang) * r, getY(), getZ() + Math.sin(ang) * r);
            mini.setTarget(getTarget());
            level.addFreshEntity(mini);
            level.sendParticles(ParticleTypes.POOF, mini.getX(), mini.getY() + 0.3, mini.getZ(), 8, 0.3, 0.3, 0.3, 0.02);
        }
    }

    private void updateNameBar() {
        int hp = (int) Math.ceil(getHealth());
        if (hp == lastHealthShown) return;
        lastHealthShown = hp;
        int total = 10;
        int filled = Math.max(0, Math.min(total, Math.round(getHealth() / getMaxHealth() * total)));
        MutableComponent bar = Component.literal("\u2588".repeat(filled)).withStyle(ChatFormatting.RED)
                .append(Component.literal("\u2588".repeat(total - filled)).withStyle(ChatFormatting.DARK_GRAY));
        setCustomName(Component.translatable(nameKey)
                .append(Component.literal(" "))
                .append(bar)
                .append(Component.literal(" " + hp + "/" + (int) getMaxHealth()).withStyle(ChatFormatting.WHITE)));
    }

    @Override
    protected float getSoundVolume() {
        return 2.0f;
    }

    @Override
    public int getAmbientSoundInterval() {
        return 160;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>("movement", 5, this::movementController));
        controllers.add(new AnimationController<BossBase>("action", 2, state -> PlayState.STOP)
                .triggerableAnim("attack", ATTACK)
                .triggerableAnim("phase", PHASE));
    }

    private PlayState movementController(AnimationTest<BossBase> state) {
        return state.setAndContinue(state.isMoving() ? WALK : IDLE);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    /** MeleeAttackGoal llama a swing() al golpear: aprovechamos para lanzar la animacion de ataque. */
    @Override
    public void swing(InteractionHand hand) {
        super.swing(hand);
        if (!level().isClientSide()) {
            triggerAnim("action", "attack");
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
