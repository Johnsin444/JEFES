package com.example.bosses;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.renderer.entity.EntityRenderers;

public class BossesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(HongoModel.LAYER, HongoModel::createBodyLayer);
        EntityRenderers.register(BossesMod.REY_HONGO, HongoRenderer::new);
    }
}
