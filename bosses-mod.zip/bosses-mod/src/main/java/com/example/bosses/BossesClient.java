package com.example.bosses;

import java.util.function.Function;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

public class BossesClient implements ClientModInitializer {
    private static <T extends Mob> void renderer(EntityType<T> type, ModelLayerLocation layer,
                                                  Function<ModelPart, EntityModel<HongoRenderState>> model,
                                                  String texture, float shadow) {
        Identifier tex = Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "textures/entity/" + texture + ".png");
        EntityRenderers.register(type,
                ctx -> new GenericRenderer<T>(ctx, model.apply(ctx.bakeLayer(layer)), tex, shadow));
    }

    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(HongoModel.LAYER, HongoModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(HongoMiniModel.LAYER, HongoMiniModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(CangrejoColosoModel.LAYER, CangrejoColosoModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(CangrejitoModel.LAYER, CangrejitoModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(EspectroFaroModel.LAYER, EspectroFaroModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(FantasmitaModel.LAYER, FantasmitaModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(BuhoEclipseModel.LAYER, BuhoEclipseModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(PollueloModel.LAYER, PollueloModel::createBodyLayer);

        EntityRenderers.register(BossesMod.REY_HONGO, HongoRenderer::new);
        EntityRenderers.register(BossesMod.HONGO_MINI, HongoMiniRenderer::new);

        renderer(BossesMod.CANGREJO_COLOSO, CangrejoColosoModel.LAYER, CangrejoColosoModel::new, "cangrejo_coloso", 1.6f);
        renderer(BossesMod.CANGREJITO, CangrejitoModel.LAYER, CangrejitoModel::new, "cangrejito", 0.5f);
        renderer(BossesMod.ESPECTRO_FARO, EspectroFaroModel.LAYER, EspectroFaroModel::new, "espectro_faro", 0.6f);
        renderer(BossesMod.FANTASMITA, FantasmitaModel.LAYER, FantasmitaModel::new, "fantasmita", 0.4f);
        renderer(BossesMod.BUHO_ECLIPSE, BuhoEclipseModel.LAYER, BuhoEclipseModel::new, "buho_eclipse", 0.8f);
        renderer(BossesMod.POLLUELO, PollueloModel.LAYER, PollueloModel::new, "polluelo", 0.4f);
    }
}
