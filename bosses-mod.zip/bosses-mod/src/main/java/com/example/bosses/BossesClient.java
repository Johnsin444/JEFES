package com.example.bosses;

import java.util.function.Function;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import com.geckolib.renderer.GeoEntityRenderer;

public class BossesClient implements ClientModInitializer {
    private static <T extends Mob> void renderer(EntityType<T> type, ModelLayerLocation layer,
                                                  Function<ModelPart, EntityModel<HongoRenderState>> model,
                                                  String texture, float shadow) {
        Identifier tex = Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "textures/entity/" + texture + ".png");
        EntityRenderers.register(type,
                ctx -> new GenericRenderer<T>(ctx, model.apply(ctx.bakeLayer(layer)), tex, shadow));
    }

    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(HongoMiniModel.LAYER, HongoMiniModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(CangrejitoModel.LAYER, CangrejitoModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(FantasmitaModel.LAYER, FantasmitaModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(PollueloModel.LAYER, PollueloModel::createBodyLayer);

        EntityRenderers.register(BossesMod.REY_HONGO, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.REY_HONGO));
        EntityRenderers.register(BossesMod.HONGO_MINI, HongoMiniRenderer::new);

        EntityRenderers.register(BossesMod.CANGREJO_COLOSO, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.CANGREJO_COLOSO));
        renderer(BossesMod.CANGREJITO, CangrejitoModel.LAYER, CangrejitoModel::new, "cangrejito", 0.5f);
        EntityRenderers.register(BossesMod.ESPECTRO_FARO, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.ESPECTRO_FARO));
        renderer(BossesMod.FANTASMITA, FantasmitaModel.LAYER, FantasmitaModel::new, "fantasmita", 0.4f);
        EntityRenderers.register(BossesMod.BUHO_ECLIPSE, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.BUHO_ECLIPSE));
        renderer(BossesMod.POLLUELO, PollueloModel.LAYER, PollueloModel::new, "polluelo", 0.4f);
    }
}
