package com.example.bosses;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import com.geckolib.renderer.GeoEntityRenderer;

public class BossesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRenderers.register(BossesMod.REY_HONGO, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.REY_HONGO));
        EntityRenderers.register(BossesMod.CANGREJO_COLOSO, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.CANGREJO_COLOSO));
        EntityRenderers.register(BossesMod.ESPECTRO_FARO, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.ESPECTRO_FARO));
        EntityRenderers.register(BossesMod.BUHO_ECLIPSE, ctx -> new GeoEntityRenderer<>(ctx, BossesMod.BUHO_ECLIPSE));
        for (var e : BossesMod.MINIS.entrySet()) {
            var type = e.getValue();
            EntityRenderers.register(type, ctx -> new GeoEntityRenderer<>(ctx, type));
        }
    }
}
