package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class BuhoEclipseModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "buho_eclipse"), "main");

    private final ModelPart wingL;
    private final ModelPart wingR;
    private final ModelPart head;

    public BuhoEclipseModel(ModelPart root) {
        super(root);
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
        this.head = root.getChild("head");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(68, 0).addBox(-9f, -26f, -6f, 18f, 20f, 12f)
                        .texOffs(116, 52).addBox(-7f, -24f, -7f, 14f, 16f, 1f)
                        .texOffs(38, 52).addBox(-12f, -28f, -7f, 24f, 3f, 15f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("cape",
                CubeListBuilder.create()
                        .texOffs(128, 0).addBox(-12f, -26f, 8f, 24f, 30f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(180, 0).addBox(-10f, -38f, -7f, 20f, 12f, 14f)
                        .texOffs(16, 75).addBox(-2f, -33f, -10f, 4f, 5f, 3f)
                        .texOffs(210, 52).addBox(-9f, -44f, -3f, 4f, 6f, 4f)
                        .texOffs(226, 52).addBox(5f, -44f, -3f, 4f, 6f, 4f)
                        .texOffs(170, 52).addBox(-6f, -41f, -4f, 12f, 3f, 8f)
                        .texOffs(66, 75).addBox(-6f, -45f, -4f, 2f, 4f, 2f)
                        .texOffs(50, 75).addBox(-1f, -46f, -4f, 2f, 5f, 2f)
                        .texOffs(74, 75).addBox(4f, -45f, -4f, 2f, 4f, 2f)
                        .texOffs(114, 75).addBox(-6f, -47f, -4f, 2f, 2f, 2f)
                        .texOffs(122, 75).addBox(-1f, -48f, -4f, 2f, 2f, 2f)
                        .texOffs(130, 75).addBox(4f, -47f, -4f, 2f, 2f, 2f)
                        .texOffs(82, 75).addBox(-6f, -45f, 2f, 2f, 4f, 2f)
                        .texOffs(58, 75).addBox(-1f, -46f, 2f, 2f, 5f, 2f)
                        .texOffs(90, 75).addBox(4f, -45f, 2f, 2f, 4f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("wing_l",
                CubeListBuilder.create()
                        .texOffs(8, 0).addBox(0f, 0f, -6f, 3f, 22f, 12f),
                PartPose.offset(10f, 0f, 0f));
        root.addOrReplaceChild("wing_r",
                CubeListBuilder.create()
                        .texOffs(38, 0).addBox(-3f, 0f, -6f, 3f, 22f, 12f),
                PartPose.offset(-10f, 0f, 0f));
        root.addOrReplaceChild("scepter",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1f, -50f, -1f, 2f, 50f, 2f)
                        .texOffs(98, 75).addBox(-2f, -34f, -2f, 4f, 2f, 4f)
                        .texOffs(146, 52).addBox(-3f, -56f, -3f, 6f, 6f, 6f)
                        .texOffs(0, 75).addBox(-2f, -62f, -2f, 4f, 6f, 4f),
                PartPose.offset(16f, 24f, -12f));
        root.addOrReplaceChild("shield",
                CubeListBuilder.create()
                        .texOffs(0, 52).addBox(-8f, -30f, -2f, 16f, 20f, 3f),
                PartPose.offset(-16f, 24f, -12f));
        root.addOrReplaceChild("legs",
                CubeListBuilder.create()
                        .texOffs(30, 75).addBox(-5f, -6f, -2f, 3f, 6f, 2f)
                        .texOffs(40, 75).addBox(2f, -6f, -2f, 3f, 6f, 2f)
                        .texOffs(138, 75).addBox(-6f, -1f, -5f, 4f, 1f, 3f)
                        .texOffs(152, 75).addBox(2f, -1f, -5f, 4f, 1f, 3f),
                PartPose.offset(0f, 24f, 0f));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float t = state.ageInTicks;
        this.root().y = Mth.sin(t * 0.18f) * 1.5f;
        float flap = 0.15f + (Mth.sin(t * 0.55f) + 1.0f) * 0.4f;
        wingL.zRot = -flap;
        wingR.zRot = flap;
        head.yRot = Mth.sin(t * 0.05f) * 0.2f;
    }
}
