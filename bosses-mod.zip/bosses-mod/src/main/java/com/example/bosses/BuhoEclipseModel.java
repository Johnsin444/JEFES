package com.example.bosses;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class BuhoEclipseModel extends EntityModel<HongoRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "buho_eclipse"), "main");

    private final ModelPart wingL;
    private final ModelPart wingR;
    private final ModelPart head;

    public BuhoEclipseModel(ModelPart root) {
        super(root);
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
        this.head = root.getChild("head");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-7f, -24f, -5f, 14f, 18f, 10f)
                        .texOffs(56, 28).addBox(-5f, -19f, -6f, 10f, 12f, 1f)
                        .texOffs(78, 28).addBox(-4f, -12f, 5f, 8f, 10f, 2f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 28).addBox(-8f, -34f, -6f, 16f, 11f, 12f)
                        .texOffs(98, 28).addBox(-7f, -39f, -2f, 3f, 5f, 3f)
                        .texOffs(110, 28).addBox(4f, -39f, -2f, 3f, 5f, 3f)
                        .texOffs(16, 51).addBox(-1f, -27f, -9f, 3f, 4f, 3f)
                        .texOffs(28, 51).addBox(-6f, -31f, -7f, 12f, 5f, 1f),
                PartPose.offset(0f, 24f, 0f));
        root.addOrReplaceChild("wing_l",
                CubeListBuilder.create()
                        .texOffs(48, 0).addBox(0f, 0f, -5f, 3f, 18f, 10f),
                PartPose.offset(7f, 2f, 0f));
        root.addOrReplaceChild("wing_r",
                CubeListBuilder.create()
                        .texOffs(74, 0).addBox(-3f, 0f, -5f, 3f, 18f, 10f),
                PartPose.offset(-7f, 2f, 0f));
        root.addOrReplaceChild("legs",
                CubeListBuilder.create()
                        .texOffs(0, 51).addBox(-4f, -6f, -2f, 2f, 6f, 2f)
                        .texOffs(8, 51).addBox(2f, -6f, -2f, 2f, 6f, 2f)
                        .texOffs(54, 51).addBox(-5f, -1f, -5f, 3f, 1f, 3f)
                        .texOffs(66, 51).addBox(2f, -1f, -5f, 3f, 1f, 3f),
                PartPose.offset(0f, 24f, 0f));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(HongoRenderState state) {
        super.setupAnim(state);
        float t = state.ageInTicks;
        this.root().y = Mth.sin(t * 0.18f) * 1.5f;
        float flap = 0.15f + (Mth.sin(t * 0.55f) + 1.0f) * 0.45f;
        wingL.zRot = -flap;
        wingR.zRot = flap;
        head.yRot = Mth.sin(t * 0.05f) * 0.2f;
    }
}
