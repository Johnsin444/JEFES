package com.example.bosses;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class ModSounds {
    private ModSounds() {}

    private static SoundEvent reg(String id) {
        Identifier identifier = Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, id);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, identifier,
                SoundEvent.createVariableRangeEvent(identifier));
    }

    public static final SoundEvent REY_HONGO_AMBIENT = reg("entity.rey_hongo.ambient");
    public static final SoundEvent REY_HONGO_HURT = reg("entity.rey_hongo.hurt");
    public static final SoundEvent REY_HONGO_DEATH = reg("entity.rey_hongo.death");
    public static final SoundEvent REY_HONGO_PHASE = reg("entity.rey_hongo.phase");
    public static final SoundEvent REY_HONGO_ATTACK = reg("entity.rey_hongo.attack");
    public static final SoundEvent CANGREJO_COLOSO_AMBIENT = reg("entity.cangrejo_coloso.ambient");
    public static final SoundEvent CANGREJO_COLOSO_HURT = reg("entity.cangrejo_coloso.hurt");
    public static final SoundEvent CANGREJO_COLOSO_DEATH = reg("entity.cangrejo_coloso.death");
    public static final SoundEvent CANGREJO_COLOSO_PHASE = reg("entity.cangrejo_coloso.phase");
    public static final SoundEvent CANGREJO_COLOSO_ATTACK = reg("entity.cangrejo_coloso.attack");
    public static final SoundEvent ESPECTRO_FARO_AMBIENT = reg("entity.espectro_faro.ambient");
    public static final SoundEvent ESPECTRO_FARO_HURT = reg("entity.espectro_faro.hurt");
    public static final SoundEvent ESPECTRO_FARO_DEATH = reg("entity.espectro_faro.death");
    public static final SoundEvent ESPECTRO_FARO_PHASE = reg("entity.espectro_faro.phase");
    public static final SoundEvent ESPECTRO_FARO_ATTACK = reg("entity.espectro_faro.attack");
    public static final SoundEvent BUHO_ECLIPSE_AMBIENT = reg("entity.buho_eclipse.ambient");
    public static final SoundEvent BUHO_ECLIPSE_HURT = reg("entity.buho_eclipse.hurt");
    public static final SoundEvent BUHO_ECLIPSE_DEATH = reg("entity.buho_eclipse.death");
    public static final SoundEvent BUHO_ECLIPSE_PHASE = reg("entity.buho_eclipse.phase");
    public static final SoundEvent BUHO_ECLIPSE_ATTACK = reg("entity.buho_eclipse.attack");
    public static final SoundEvent HONGO_MINI_AMBIENT = reg("entity.hongo_mini.ambient");
    public static final SoundEvent HONGO_MINI_HURT = reg("entity.hongo_mini.hurt");
    public static final SoundEvent HONGO_MINI_DEATH = reg("entity.hongo_mini.death");
    public static final SoundEvent CANGREJITO_AMBIENT = reg("entity.cangrejito.ambient");
    public static final SoundEvent CANGREJITO_HURT = reg("entity.cangrejito.hurt");
    public static final SoundEvent CANGREJITO_DEATH = reg("entity.cangrejito.death");
    public static final SoundEvent FANTASMITA_AMBIENT = reg("entity.fantasmita.ambient");
    public static final SoundEvent FANTASMITA_HURT = reg("entity.fantasmita.hurt");
    public static final SoundEvent FANTASMITA_DEATH = reg("entity.fantasmita.death");
    public static final SoundEvent POLLUELO_AMBIENT = reg("entity.polluelo.ambient");
    public static final SoundEvent POLLUELO_HURT = reg("entity.polluelo.hurt");
    public static final SoundEvent POLLUELO_DEATH = reg("entity.polluelo.death");

    public static void init() {
    }
}
