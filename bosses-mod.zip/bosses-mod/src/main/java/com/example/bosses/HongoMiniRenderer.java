package com.example.bosses;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class HongoMiniRenderer extends MobRenderer<HongoMini, HongoRenderState, HongoMiniModel> {
    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(BossesMod.MOD_ID, "textures/entity/hongo_mini.png");

    public HongoMiniRenderer(EntityRendererProvider.Context context) {
        super(context, new HongoMiniModel(context.bakeLayer(HongoMiniModel.LAYER)), 0.4f);
    }

    @Override
    public HongoRenderState createRenderState() {
        return new HongoRenderState();
    }

    @Override
    public Identifier getTextureLocation(HongoRenderState state) {
        return TEXTURE;
    }
}
